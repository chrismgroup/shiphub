import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import test from "node:test";

const apiBaseUrl = process.env.API_BASE_URL ?? "http://localhost:80/api";
const onePixelPng = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScL5vAAAAABJRU5ErkJggg==",
  "base64",
);

async function request(path, options = {}) {
  const response = await fetch(`${apiBaseUrl}${path}`, options);
  const payload = await response.json().catch(() => undefined);
  return { response, payload };
}

test("replays a completed vessel photo upload after its response is lost", async (t) => {
  const suffix = randomUUID().replaceAll("-", "");
  const { response: registrationResponse, payload: registration } = await request(
    "/vessels/auth/register",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Photo Retry Test",
        email: `photo-retry-${suffix}@example.test`,
        password: "test-password",
        role: "owner",
      }),
    },
  );
  assert.equal(registrationResponse.status, 201);
  const headers = {
    Authorization: `Bearer ${registration.token}`,
    "Content-Type": "application/json",
  };

  const { response: vesselResponse, payload: vessel } = await request("/vessels", {
    method: "POST",
    headers,
    body: JSON.stringify({
      name: `Photo retry ${suffix}`,
      vesselType: "Tugboat",
    }),
  });
  assert.equal(vesselResponse.status, 201);

  let photoId;
  t.after(async () => {
    if (photoId) {
      await request(`/vessels/${vessel.id}/photos/${photoId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${registration.token}` },
      });
    }
  });

  const uploadKey = `photo_${suffix}`;
  const uploadHeaders = {
    Authorization: `Bearer ${registration.token}`,
    "Content-Type": "image/png",
    "X-Upload-Key": uploadKey,
  };
  const firstUpload = await request(`/vessels/${vessel.id}/photos/upload`, {
    method: "POST",
    headers: uploadHeaders,
    body: onePixelPng,
  });
  assert.equal(firstUpload.response.status, 201);
  photoId = firstUpload.payload.id;

  const replayUpload = await request(`/vessels/${vessel.id}/photos/upload`, {
    method: "POST",
    headers: uploadHeaders,
    body: onePixelPng,
  });
  assert.equal(replayUpload.response.status, 200);
  assert.equal(replayUpload.payload.id, firstUpload.payload.id);

  const { response: detailResponse, payload: vesselDetail } = await request(
    `/vessels/${vessel.id}`,
    { headers: { Authorization: `Bearer ${registration.token}` } },
  );
  assert.equal(detailResponse.status, 200);
  assert.equal(vesselDetail.photos.length, 1);
  assert.equal(vesselDetail.photos[0].id, firstUpload.payload.id);
});