import { randomUUID } from "crypto";
import { Readable, type Writable } from "stream";
import { File, Storage } from "@google-cloud/storage";

const REPLIT_SIDECAR_ENDPOINT = "http://127.0.0.1:1106";
const VESSEL_PHOTO_PREFIX = "vessel-photos/";

const storage = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

function privateObjectDir(): string {
  const value = process.env.PRIVATE_OBJECT_DIR;
  if (!value) throw new Error("PRIVATE_OBJECT_DIR is not configured");
  return value.replace(/\/+$/, "");
}

function parseStoragePath(path: string): { bucketName: string; objectName: string } {
  const parts = path.replace(/^\/+/, "").split("/");
  if (parts.length < 2) throw new Error("Invalid object storage path");
  return { bucketName: parts[0], objectName: parts.slice(1).join("/") };
}

export function isVesselPhotoPath(path: unknown): path is string {
  return typeof path === "string" &&
    /^\/objects\/vessel-photos\/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(path);
}

function fileForPath(objectPath: string): File {
  if (!isVesselPhotoPath(objectPath)) throw new Error("Invalid vessel photo path");
  const relativePath = objectPath.slice("/objects/".length);
  const { bucketName, objectName } = parseStoragePath(
    `${privateObjectDir()}/${relativePath}`,
  );
  return storage.bucket(bucketName).file(objectName);
}

export function createVesselPhotoUpload(
  contentType: ValidatedVesselPhoto["contentType"],
): {
  objectPath: string;
  file: File;
  writeStream: Writable;
} {
  const objectPath = `/objects/${VESSEL_PHOTO_PREFIX}${randomUUID()}`;
  const file = fileForPath(objectPath);
  return {
    objectPath,
    file,
    writeStream: file.createWriteStream({
      resumable: false,
      metadata: { contentType },
    }),
  };
}

export async function getVesselPhotoFile(objectPath: string): Promise<File | null> {
  if (!isVesselPhotoPath(objectPath)) return null;
  const file = fileForPath(objectPath);
  const [exists] = await file.exists();
  return exists ? file : null;
}

export type ValidatedVesselPhoto = {
  file: File;
  contentType: "image/jpeg" | "image/png" | "image/webp";
};

function detectedImageType(bytes: Buffer): ValidatedVesselPhoto["contentType"] | null {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return "image/jpeg";
  }
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    return "image/png";
  }
  if (bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP") {
    return "image/webp";
  }
  return null;
}

export async function validateVesselPhoto(
  objectPath: string,
): Promise<ValidatedVesselPhoto | null> {
  const file = await getVesselPhotoFile(objectPath);
  if (!file) return null;
  const [metadata] = await file.getMetadata();
  const size = Number(metadata.size);
  const metadataType = String(metadata.contentType || "").toLowerCase();
  if (!Number.isFinite(size) || size <= 0 || size > 10 * 1024 * 1024 ||
      !["image/jpeg", "image/png", "image/webp"].includes(metadataType)) {
    return null;
  }
  const [bytes] = await file.download({ start: 0, end: 11 });
  const contentType = detectedImageType(bytes);
  return contentType && contentType === metadataType ? { file, contentType } : null;
}

export async function deleteVesselPhoto(objectPath: string): Promise<void> {
  if (!isVesselPhotoPath(objectPath)) return;
  await fileForPath(objectPath).delete({ ignoreNotFound: true });
}

export async function streamVesselPhoto(
  file: File,
  contentType: ValidatedVesselPhoto["contentType"],
): Promise<{ body: Readable; contentType: string; contentLength?: string }> {
  const [metadata] = await file.getMetadata();
  return {
    body: file.createReadStream(),
    contentType,
    contentLength: metadata.size ? String(metadata.size) : undefined,
  };
}