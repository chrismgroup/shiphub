import { and, eq, inArray, lt } from "drizzle-orm";
import { db, charterPartiesTable, vesselsTable } from "@workspace/db";
import { logger } from "./logger";

let lastExpireRun = 0;
const EXPIRE_INTERVAL_MS = 60_000; // run at most once per minute

export async function expireHires(): Promise<void> {
  const now = Date.now();
  if (now - lastExpireRun < EXPIRE_INTERVAL_MS) return;
  lastExpireRun = now;

  try {
    const expired = await db
      .select({ id: charterPartiesTable.id, vesselId: charterPartiesTable.vesselId })
      .from(charterPartiesTable)
      .where(
        and(
          eq(charterPartiesTable.status, "active"),
          lt(charterPartiesTable.hireEnd, new Date()),
        ),
      );

    if (expired.length === 0) return;

    const ids = expired.map((c) => c.id);
    const vesselIds = [...new Set(expired.map((c) => c.vesselId))];

    await db
      .update(charterPartiesTable)
      .set({ status: "terminated", updatedAt: new Date() })
      .where(inArray(charterPartiesTable.id, ids));

    await db
      .update(vesselsTable)
      .set({ status: "available", updatedAt: new Date() })
      .where(inArray(vesselsTable.id, vesselIds));

    logger.info({ count: expired.length }, "Expired charter hires");
  } catch (err) {
    logger.error({ err }, "Failed to expire hires");
  }
}
