/**
 * charterHub — lightweight WebSocket broadcast hub for charter-party events.
 *
 * Clients authenticate by sending their JWT token as the `token` URL query
 * parameter when opening the WebSocket.  Once authenticated they receive a
 * pushed message whenever a charter they are a party to changes.
 *
 * Message format (server → client):
 *   { type: "charter_updated", charterId: number }
 *   { type: "charter_list_updated" }      — list-level invalidation
 *   { type: "ping" }                       — keepalive
 */

import { WebSocketServer, WebSocket } from "ws";
import { IncomingMessage } from "http";
import { Server } from "http";
import jwt from "jsonwebtoken";
import { logger } from "./logger";
import type { VesselAuthPayload } from "../middleware/vesselAuth";

interface AuthedClient {
  ws: WebSocket;
  userId: number;
  role: string;
  isAlive: boolean;
}

const clients = new Set<AuthedClient>();

let wss: WebSocketServer | null = null;

/** Attach the WebSocket server to an existing HTTP server. */
export function attachCharterHub(server: Server): void {
  wss = new WebSocketServer({ server, path: "/api/ws/charters" });

  const JWT_SECRET = process.env.JWT_SECRET;

  wss.on("connection", (ws: WebSocket, req: IncomingMessage) => {
    // ── Authenticate ──────────────────────────────────────────────────────
    let payload: VesselAuthPayload | null = null;
    try {
      const rawUrl = req.url ?? "";
      const qs = new URLSearchParams(rawUrl.split("?")[1] ?? "");
      const token = qs.get("token");
      if (token && JWT_SECRET) {
        payload = jwt.verify(token, JWT_SECRET) as VesselAuthPayload;
        if (payload.scope !== "vessel") payload = null;
      }
    } catch {
      /* invalid token */
    }

    if (!payload) {
      ws.close(4001, "Unauthorized");
      return;
    }

    const client: AuthedClient = {
      ws,
      userId: payload.userId,
      role: payload.role,
      isAlive: true,
    };
    clients.add(client);
    logger.debug({ userId: client.userId }, "charter ws client connected");

    ws.on("pong", () => {
      client.isAlive = true;
    });

    ws.on("close", () => {
      clients.delete(client);
      logger.debug({ userId: client.userId }, "charter ws client disconnected");
    });

    ws.on("error", (err) => {
      logger.warn({ err, userId: client.userId }, "charter ws error");
      clients.delete(client);
    });

    // Send an initial ack so the client knows the connection is ready
    safeSend(ws, { type: "connected" });
  });

  // Heartbeat — ping every 30 s and drop dead connections
  const heartbeat = setInterval(() => {
    for (const client of clients) {
      if (!client.isAlive) {
        client.ws.terminate();
        clients.delete(client);
        continue;
      }
      client.isAlive = false;
      client.ws.ping();
    }
  }, 30_000);

  wss.on("close", () => clearInterval(heartbeat));

  logger.info("Charter WebSocket hub attached at /api/ws/charters");
}

/**
 * Broadcast a charter-updated event to the owner and charterer of the
 * affected charter (and to admins).
 */
export function broadcastCharterUpdate(
  charterId: number,
  ownerId: number,
  chartererId: number,
): void {
  const msg = JSON.stringify({ type: "charter_updated", charterId });
  const listMsg = JSON.stringify({ type: "charter_list_updated" });

  for (const client of clients) {
    const isParty =
      client.userId === ownerId ||
      client.userId === chartererId ||
      client.role === "admin";

    if (isParty && client.ws.readyState === WebSocket.OPEN) {
      safeSend(client.ws, null, msg);      // detail update
      safeSend(client.ws, null, listMsg);  // list update
    }
  }
}

function safeSend(
  ws: WebSocket,
  data: object | null,
  raw?: string,
): void {
  try {
    ws.send(raw ?? JSON.stringify(data));
  } catch {
    /* ignore send errors */
  }
}
