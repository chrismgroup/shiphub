import bcrypt from "bcryptjs";
import { Transform } from "stream";
import { pipeline } from "stream/promises";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import jwt from "jsonwebtoken";
import {
  db,
  vesselUsersTable,
  vesselsTable,
  vesselContactsTable,
  charterPartiesTable,
  vesselNotificationsTable,
  vesselPhotosTable,
} from "@workspace/db";
import {
  requireVesselAuth,
  optionalVesselAuth,
  requireVesselRole,
} from "../middleware/vesselAuth";
import { expireHires } from "../lib/expireHires";
import {
  createVesselPhotoUpload,
  deleteVesselPhoto,
  isVesselPhotoPath,
  streamVesselPhoto,
  validateVesselPhoto,
} from "../lib/vesselPhotoStorage";
import { broadcastCharterUpdate } from "../lib/charterHub";

const router: IRouter = Router();

const JWT_SECRET = process.env.JWT_SECRET;
const BCRYPT_ROUNDS = 12;
const CURRENT_YEAR = new Date().getFullYear();
const MAX_VESSEL_PHOTOS = 5;
const MAX_VESSEL_PHOTO_BYTES = 10 * 1024 * 1024;
const PHOTO_VESSEL_LOCK_NAMESPACE = 73_902;

class PhotoTooLargeError extends Error {}
class InvalidPhotoError extends Error {}
class PhotoCapacityError extends Error {}
class InvalidPhotoOrderError extends Error {}

// ── Helpers ───────────────────────────────────────────────────────────────────

function pId(p: string | string[]): number {
  return parseInt(Array.isArray(p) ? p[0] : p, 10);
}

function safeUser(u: typeof vesselUsersTable.$inferSelect) {
  const { password: _, ...rest } = u;
  return rest;
}

function signToken(user: typeof vesselUsersTable.$inferSelect): string {
  if (!JWT_SECRET) throw new Error("JWT_SECRET not set");
  return jwt.sign(
    { userId: user.id, email: user.email, role: user.role, scope: "vessel" },
    JWT_SECRET,
    { expiresIn: "24h" },
  );
}

async function createNotification(
  userId: number,
  type: string,
  title: string,
  message: string,
  relatedId?: number,
): Promise<void> {
  try {
    await db
      .insert(vesselNotificationsTable)
      .values({ userId, type, title, message, relatedId: relatedId ?? null });
  } catch {
    // Swallow notification errors — they are non-critical
  }
}

function validateIMONumber(v: unknown): string | null {
  if (!v || v === "") return null;
  const s = String(v).trim();
  if (!/^\d{7}$/.test(s)) return "IMO number must be exactly 7 digits";
  const digits = s.split("").map(Number);
  const sum = digits
    .slice(0, 6)
    .reduce((a, d, i) => a + d * [7, 6, 5, 4, 3, 2][i], 0);
  if (sum % 10 !== digits[6]) return "IMO number has an invalid check digit";
  return null;
}

function validateNum(
  v: unknown,
  label: string,
  min: number,
  max: number,
): string | null {
  if (!v && v !== 0) return null;
  const n = Number(v);
  if (isNaN(n) || !isFinite(n)) return `${label} must be a number`;
  if (n < min) return `${label} must be at least ${min}`;
  if (n > max) return `${label} must be at most ${max.toLocaleString()}`;
  return null;
}

function validateYear(v: unknown): string | null {
  if (!v) return null;
  const n = Number(v);
  if (!Number.isInteger(n)) return "Year built must be a whole number";
  if (n < 1900) return "Year built must be 1900 or later";
  if (n > CURRENT_YEAR + 1) return "Year built cannot be in the future";
  return null;
}

function validateVesselFields(
  f: Record<string, unknown>,
): Record<string, string> {
  const e: Record<string, string> = {};
  const checks: [string | null, string][] = [
    [validateIMONumber(f.imoNumber), "imoNumber"],
    [validateNum(f.dwt, "DWT", 1, 500_000), "dwt"],
    [validateNum(f.grt, "GRT", 1, 300_000), "grt"],
    [validateYear(f.yearBuilt), "yearBuilt"],
    [validateNum(f.loa, "LOA", 1, 500), "loa"],
    [validateNum(f.beam, "Beam", 1, 100), "beam"],
    [validateNum(f.draft, "Draft", 0.1, 30), "draft"],
  ];
  for (const [msg, field] of checks) if (msg) e[field] = msg;
  return e;
}

async function enrichCP(cp: Record<string, unknown>) {
  const [c] = await db
    .select({ name: vesselUsersTable.name })
    .from(vesselUsersTable)
    .where(eq(vesselUsersTable.id, cp.chartererId as number));
  const [o] = await db
    .select({ name: vesselUsersTable.name })
    .from(vesselUsersTable)
    .where(eq(vesselUsersTable.id, cp.ownerId as number));
  return { ...cp, chartererName: c?.name, ownerName: o?.name };
}

// ── AUTH ──────────────────────────────────────────────────────────────────────

router.post(
  "/vessels/auth/register",
  async (req, res): Promise<void> => {
    if (!JWT_SECRET) {
      res.status(503).json({ error: "Service unavailable" });
      return;
    }
    const { name, email, password, role, company, phone } = req.body ?? {};
    if (!name || !email || !password) {
      res.status(400).json({ error: "name, email, and password are required" });
      return;
    }
    if (String(password).length < 6) {
      res
        .status(400)
        .json({ error: "Password must be at least 6 characters" });
      return;
    }
    const resolvedRole = ["client", "broker", "owner"].includes(role)
      ? role
      : "client";
    try {
      const [existing] = await db
        .select({ id: vesselUsersTable.id })
        .from(vesselUsersTable)
        .where(eq(vesselUsersTable.email, String(email).toLowerCase().trim()));
      if (existing) {
        res.status(409).json({ error: "Email already registered" });
        return;
      }
      const hashed = await bcrypt.hash(String(password), BCRYPT_ROUNDS);
      const [user] = await db
        .insert(vesselUsersTable)
        .values({
          name: String(name).trim(),
          email: String(email).toLowerCase().trim(),
          password: hashed,
          role: resolvedRole,
          company: company ?? null,
          phone: phone ?? null,
        })
        .returning();
      res.status(201).json({ token: signToken(user), user: safeUser(user) });
    } catch (err: unknown) {
      const pgErr = err as { code?: string };
      if (pgErr?.code === "23505") {
        res.status(409).json({ error: "Email already registered" });
        return;
      }
      throw err;
    }
  },
);

router.post(
  "/vessels/auth/login",
  async (req, res): Promise<void> => {
    if (!JWT_SECRET) {
      res.status(503).json({ error: "Service unavailable" });
      return;
    }
    const { email, password } = req.body ?? {};
    if (!email || !password) {
      res.status(400).json({ error: "email and password required" });
      return;
    }
    const [user] = await db
      .select()
      .from(vesselUsersTable)
      .where(
        eq(vesselUsersTable.email, String(email).toLowerCase().trim()),
      );
    if (!user) {
      await bcrypt.compare(
        "dummy",
        "$2a$12$dummy.hash.to.prevent.timing.attacks",
      );
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    if (!(await bcrypt.compare(String(password), user.password))) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    res.json({ token: signToken(user), user: safeUser(user) });
  },
);

// ── VESSELS ───────────────────────────────────────────────────────────────────

router.get(
  "/vessels",
  optionalVesselAuth,
  async (req, res): Promise<void> => {
    await expireHires();
    const { vesselType, status, tradingArea, search } =
      req.query as Record<string, string>;

    let rows = await db
      .select({
        id: vesselsTable.id,
        ownerId: vesselsTable.ownerId,
        name: vesselsTable.name,
        imoNumber: vesselsTable.imoNumber,
        vesselType: vesselsTable.vesselType,
        flag: vesselsTable.flag,
        dwt: vesselsTable.dwt,
        grt: vesselsTable.grt,
        yearBuilt: vesselsTable.yearBuilt,
        loa: vesselsTable.loa,
        beam: vesselsTable.beam,
        draft: vesselsTable.draft,
        classificationSociety: vesselsTable.classificationSociety,
        tradingArea: vesselsTable.tradingArea,
        description: vesselsTable.description,
        status: vesselsTable.status,
        createdAt: vesselsTable.createdAt,
        updatedAt: vesselsTable.updatedAt,
        ownerName: vesselUsersTable.name,
      })
      .from(vesselsTable)
      .leftJoin(
        vesselUsersTable,
        eq(vesselsTable.ownerId, vesselUsersTable.id),
      );

    if (vesselType && vesselType !== "All")
      rows = rows.filter((v) => v.vesselType === vesselType);
    if (status && status !== "All")
      rows = rows.filter((v) => v.status === status);
    if (tradingArea)
      rows = rows.filter((v) =>
        v.tradingArea?.toLowerCase().includes(tradingArea.toLowerCase()),
      );
    if (search) {
      const s = search.toLowerCase();
      rows = rows.filter(
        (v) =>
          v.name.toLowerCase().includes(s) ||
          v.imoNumber?.toLowerCase().includes(s) ||
          v.vesselType.toLowerCase().includes(s) ||
          v.flag?.toLowerCase().includes(s),
      );
    }

    const ids = rows.map((v) => v.id);
    const photos =
      ids.length > 0
        ? await db
            .select({
              vesselId: vesselPhotosTable.vesselId,
              objectPath: vesselPhotosTable.objectPath,
            })
            .from(vesselPhotosTable)
            .where(inArray(vesselPhotosTable.vesselId, ids))
            .orderBy(
              asc(vesselPhotosTable.sortOrder),
              asc(vesselPhotosTable.uploadedAt),
            )
        : [];

    const photoMap = new Map<number, string>();
    for (const p of photos) {
      if (!photoMap.has(p.vesselId)) photoMap.set(p.vesselId, p.objectPath);
    }

    res.json(rows.map((v) => ({ ...v, firstPhotoPath: photoMap.get(v.id) ?? null })));
  },
);

router.get(
  "/vessels/:id",
  optionalVesselAuth,
  async (req, res): Promise<void> => {
    await expireHires();
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [vessel] = await db
      .select({
        id: vesselsTable.id,
        ownerId: vesselsTable.ownerId,
        name: vesselsTable.name,
        imoNumber: vesselsTable.imoNumber,
        vesselType: vesselsTable.vesselType,
        flag: vesselsTable.flag,
        dwt: vesselsTable.dwt,
        grt: vesselsTable.grt,
        yearBuilt: vesselsTable.yearBuilt,
        loa: vesselsTable.loa,
        beam: vesselsTable.beam,
        draft: vesselsTable.draft,
        classificationSociety: vesselsTable.classificationSociety,
        tradingArea: vesselsTable.tradingArea,
        description: vesselsTable.description,
        status: vesselsTable.status,
        createdAt: vesselsTable.createdAt,
        updatedAt: vesselsTable.updatedAt,
        ownerName: vesselUsersTable.name,
      })
      .from(vesselsTable)
      .leftJoin(
        vesselUsersTable,
        eq(vesselsTable.ownerId, vesselUsersTable.id),
      )
      .where(eq(vesselsTable.id, id));

    if (!vessel) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }

    const contacts = req.vesselAuth
      ? await db
          .select()
          .from(vesselContactsTable)
          .where(eq(vesselContactsTable.vesselId, id))
      : [];
    const photos = await db
      .select()
      .from(vesselPhotosTable)
      .where(eq(vesselPhotosTable.vesselId, id))
      .orderBy(
        asc(vesselPhotosTable.sortOrder),
        asc(vesselPhotosTable.uploadedAt),
      );

    res.json({ ...vessel, contacts, photos });
  },
);

router.post(
  "/vessels",
  requireVesselAuth,
  requireVesselRole(["owner", "admin"]),
  async (req, res): Promise<void> => {
    const {
      name,
      imoNumber,
      vesselType,
      flag,
      dwt,
      grt,
      yearBuilt,
      loa,
      beam,
      draft,
      classificationSociety,
      tradingArea,
      description,
      status,
      contacts,
    } = req.body ?? {};

    if (!name || !vesselType) {
      res.status(400).json({ error: "name and vesselType are required" });
      return;
    }
    const fieldErrors = validateVesselFields({
      imoNumber,
      dwt,
      grt,
      yearBuilt,
      loa,
      beam,
      draft,
    });
    if (Object.keys(fieldErrors).length > 0) {
      res.status(400).json({ error: "Validation failed", fields: fieldErrors });
      return;
    }

    const [vessel] = await db
      .insert(vesselsTable)
      .values({
        ownerId: req.vesselAuth!.userId,
        name: String(name).trim(),
        imoNumber: imoNumber ?? null,
        vesselType: String(vesselType),
        flag: flag ?? null,
        dwt: dwt ? String(dwt) : null,
        grt: grt ? String(grt) : null,
        yearBuilt: yearBuilt ? parseInt(yearBuilt) : null,
        loa: loa ? String(loa) : null,
        beam: beam ? String(beam) : null,
        draft: draft ? String(draft) : null,
        classificationSociety: classificationSociety ?? null,
        tradingArea: tradingArea ?? null,
        description: description ?? null,
        status: status ?? "available",
      })
      .returning();

    if (contacts?.length > 0) {
      await db.insert(vesselContactsTable).values(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        contacts.map((c: any) => ({
          vesselId: vessel.id,
          contactName: String(c.contactName || "Contact").trim(),
          phone: c.phone ?? null,
          email: c.email ?? null,
          address: c.address ?? null,
        })),
      );
    }

    res.status(201).json(vessel);
  },
);

router.put(
  "/vessels/:id",
  requireVesselAuth,
  requireVesselRole(["owner", "admin"]),
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [existing] = await db
      .select()
      .from(vesselsTable)
      .where(eq(vesselsTable.id, id));
    if (!existing) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (auth.role !== "admin" && existing.ownerId !== auth.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const {
      name,
      imoNumber,
      vesselType,
      flag,
      dwt,
      grt,
      yearBuilt,
      loa,
      beam,
      draft,
      classificationSociety,
      tradingArea,
      description,
      contacts,
    } = req.body ?? {};

    const fieldErrors = validateVesselFields({
      imoNumber,
      dwt,
      grt,
      yearBuilt,
      loa,
      beam,
      draft,
    });
    if (Object.keys(fieldErrors).length > 0) {
      res.status(400).json({ error: "Validation failed", fields: fieldErrors });
      return;
    }

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (name !== undefined) updates.name = name;
    if (imoNumber !== undefined) updates.imoNumber = imoNumber;
    if (vesselType !== undefined) updates.vesselType = vesselType;
    if (flag !== undefined) updates.flag = flag;
    if (dwt !== undefined) updates.dwt = dwt ? String(dwt) : null;
    if (grt !== undefined) updates.grt = grt ? String(grt) : null;
    if (yearBuilt !== undefined)
      updates.yearBuilt = yearBuilt ? parseInt(yearBuilt) : null;
    if (loa !== undefined) updates.loa = loa ? String(loa) : null;
    if (beam !== undefined) updates.beam = beam ? String(beam) : null;
    if (draft !== undefined) updates.draft = draft ? String(draft) : null;
    if (classificationSociety !== undefined)
      updates.classificationSociety = classificationSociety;
    if (tradingArea !== undefined) updates.tradingArea = tradingArea;
    if (description !== undefined) updates.description = description;

    const [updated] = await db
      .update(vesselsTable)
      .set(updates)
      .where(eq(vesselsTable.id, id))
      .returning();

    if (contacts !== undefined) {
      await db
        .delete(vesselContactsTable)
        .where(eq(vesselContactsTable.vesselId, id));
      if (contacts.length > 0) {
        await db.insert(vesselContactsTable).values(
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          contacts.map((c: any) => ({
            vesselId: id,
            contactName: String(c.contactName || "Contact").trim(),
            phone: c.phone ?? null,
            email: c.email ?? null,
            address: c.address ?? null,
          })),
        );
      }
    }

    res.json(updated);
  },
);

router.patch(
  "/vessels/:id/status",
  requireVesselAuth,
  requireVesselRole(["owner", "admin"]),
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [existing] = await db
      .select()
      .from(vesselsTable)
      .where(eq(vesselsTable.id, id));
    if (!existing) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (auth.role !== "admin" && existing.ownerId !== auth.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    const { status } = req.body ?? {};
    if (!["available", "laid_up", "decommissioned"].includes(status)) {
      res.status(400).json({ error: "Invalid status" });
      return;
    }
    if (existing.status === "on_hire") {
      res
        .status(400)
        .json({ error: "Cannot change status of vessel on hire" });
      return;
    }
    const [updated] = await db
      .update(vesselsTable)
      .set({ status, updatedAt: new Date() })
      .where(eq(vesselsTable.id, id))
      .returning();
    res.json(updated);
  },
);

// ── VESSEL PHOTOS ─────────────────────────────────────────────────────────────

router.get("/vessel-photos/*path", async (req, res): Promise<void> => {
  const rawPath = req.params.path;
  const path = Array.isArray(rawPath) ? rawPath.join("/") : rawPath;
  const objectPath = `/objects/${path}`;
  if (!isVesselPhotoPath(objectPath)) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }
  const [registeredPhoto] = await db
    .select({ id: vesselPhotosTable.id })
    .from(vesselPhotosTable)
    .where(eq(vesselPhotosTable.objectPath, objectPath));
  if (!registeredPhoto) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }
  try {
    const photo = await validateVesselPhoto(objectPath);
    if (!photo) {
      res.status(404).json({ error: "Photo not found" });
      return;
    }
    const stream = await streamVesselPhoto(photo.file, photo.contentType);
    res.setHeader("Content-Type", stream.contentType);
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cache-Control", "public, max-age=3600");
    if (stream.contentLength) res.setHeader("Content-Length", stream.contentLength);
    stream.body.on("error", (error) => {
      req.log.error({ err: error }, "Error streaming vessel photo");
      if (!res.headersSent) res.status(500).end();
      else res.destroy(error);
    });
    stream.body.pipe(res);
  } catch (error) {
    req.log.error({ err: error }, "Error loading vessel photo");
    res.status(500).json({ error: "Failed to load photo" });
  }
});

router.get(
  "/vessels/:id/photos",
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const photos = await db
      .select()
      .from(vesselPhotosTable)
      .where(eq(vesselPhotosTable.vesselId, id))
      .orderBy(
        asc(vesselPhotosTable.sortOrder),
        asc(vesselPhotosTable.uploadedAt),
      );
    res.json(photos);
  },
);

router.patch(
  "/vessels/:id/photos/reorder",
  requireVesselAuth,
  requireVesselRole(["owner", "admin"]),
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }

    const { photoIds } = req.body ?? {};
    if (
      !Array.isArray(photoIds) ||
      photoIds.some(
        (photoId: unknown) =>
          !Number.isSafeInteger(photoId) || (photoId as number) <= 0,
      )
    ) {
      res
        .status(400)
        .json({ error: "photoIds must be an array of positive integers" });
      return;
    }

    const requestedPhotoIds = photoIds as number[];
    if (new Set(requestedPhotoIds).size !== requestedPhotoIds.length) {
      res.status(400).json({ error: "photoIds must not contain duplicates" });
      return;
    }

    const [vessel] = await db
      .select()
      .from(vesselsTable)
      .where(eq(vesselsTable.id, id));
    if (!vessel) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }

    const auth = req.vesselAuth!;
    if (auth.role !== "admin" && vessel.ownerId !== auth.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    try {
      const reorderedPhotos = await db.transaction(async (tx) => {
        await tx.execute(
          sql`select pg_advisory_xact_lock(${PHOTO_VESSEL_LOCK_NAMESPACE}, ${id})`,
        );
        const currentPhotos = await tx
          .select()
          .from(vesselPhotosTable)
          .where(eq(vesselPhotosTable.vesselId, id));
        const currentPhotoIds = new Set(currentPhotos.map((photo) => photo.id));

        if (
          currentPhotos.length !== requestedPhotoIds.length ||
          requestedPhotoIds.some((photoId) => !currentPhotoIds.has(photoId))
        ) {
          throw new InvalidPhotoOrderError(
            "photoIds must contain every photo belonging to this vessel",
          );
        }

        for (const [sortOrder, photoId] of requestedPhotoIds.entries()) {
          await tx
            .update(vesselPhotosTable)
            .set({ sortOrder })
            .where(
              and(
                eq(vesselPhotosTable.id, photoId),
                eq(vesselPhotosTable.vesselId, id),
              ),
            );
        }

        await tx
          .update(vesselsTable)
          .set({ updatedAt: new Date() })
          .where(eq(vesselsTable.id, id));

        return tx
          .select()
          .from(vesselPhotosTable)
          .where(eq(vesselPhotosTable.vesselId, id))
          .orderBy(
            asc(vesselPhotosTable.sortOrder),
            asc(vesselPhotosTable.uploadedAt),
          );
      });

      res.json(reorderedPhotos);
    } catch (error) {
      if (error instanceof InvalidPhotoOrderError) {
        res.status(400).json({ error: error.message });
        return;
      }
      throw error;
    }
  },
);

router.post(
  "/vessels/:id/photos/upload",
  requireVesselAuth,
  requireVesselRole(["owner", "admin"]),
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const contentType = String(req.headers["content-type"] || "").toLowerCase();
    if (!["image/jpeg", "image/png", "image/webp"].includes(contentType)) {
      res.status(415).json({ error: "Only raw JPEG, PNG, and WebP image bodies are supported" });
      return;
    }
    const declaredLength = req.headers["content-length"];
    if (declaredLength !== undefined) {
      const length = Number(declaredLength);
      if (!Number.isSafeInteger(length) || length < 0) {
        res.status(400).json({ error: "Invalid Content-Length" });
        return;
      }
      if (length > MAX_VESSEL_PHOTO_BYTES) {
        res.status(413).json({ error: "Image must be 10 MB or smaller" });
        req.resume();
        return;
      }
    }
    const [vessel] = await db
      .select()
      .from(vesselsTable)
      .where(eq(vesselsTable.id, id));
    if (!vessel) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (auth.role !== "admin" && vessel.ownerId !== auth.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    const header = req.headers["x-upload-key"];
    const uploadKey = Array.isArray(header) ? header[0] : header;
    if (!uploadKey || !/^[A-Za-z0-9_-]{16,128}$/.test(uploadKey)) {
      res.status(400).json({ error: "A valid X-Upload-Key header is required" });
      return;
    }

    const [previouslyUploaded] = await db
      .select()
      .from(vesselPhotosTable)
      .where(
        and(
          eq(vesselPhotosTable.vesselId, id),
          eq(vesselPhotosTable.uploadKey, uploadKey),
        ),
      )
      .limit(1);
    if (previouslyUploaded) {
      req.resume();
      res.status(200).json(previouslyUploaded);
      return;
    }

    const upload = createVesselPhotoUpload(
      contentType as "image/jpeg" | "image/png" | "image/webp",
    );
    let exceededLimit = false;
    try {
      let received = 0;
      const limit = new Transform({
        transform(chunk: Buffer, _encoding, callback) {
          received += chunk.length;
          if (received > MAX_VESSEL_PHOTO_BYTES) {
            exceededLimit = true;
            callback(new PhotoTooLargeError("Image exceeds 10 MB"));
            return;
          }
          callback(null, chunk);
        },
      });
      await pipeline(req, limit, upload.writeStream);

      const validPhoto = await validateVesselPhoto(upload.objectPath);
      if (!validPhoto || validPhoto.contentType !== contentType) {
        throw new InvalidPhotoError("Uploaded body is not a valid image");
      }

      const result = await db.transaction(async (tx) => {
        await tx.execute(
          sql`select pg_advisory_xact_lock(${PHOTO_VESSEL_LOCK_NAMESPACE}, ${id})`,
        );
        const [previouslyRegistered] = await tx
          .select()
          .from(vesselPhotosTable)
          .where(
            and(
              eq(vesselPhotosTable.vesselId, id),
              eq(vesselPhotosTable.uploadKey, uploadKey),
            ),
          )
          .limit(1);
        if (previouslyRegistered) {
          return { photo: previouslyRegistered, replayed: true };
        }
        const existing = await tx
          .select({ id: vesselPhotosTable.id })
          .from(vesselPhotosTable)
          .where(eq(vesselPhotosTable.vesselId, id));
        if (existing.length >= MAX_VESSEL_PHOTOS) {
          throw new PhotoCapacityError("Maximum 5 photos per vessel");
        }
        const [created] = await tx
          .insert(vesselPhotosTable)
          .values({
            vesselId: id,
            objectPath: upload.objectPath,
            uploadKey,
            sortOrder: existing.length,
          })
          .returning();
        return { photo: created, replayed: false };
      });
      if (result.replayed) {
        try {
          await deleteVesselPhoto(upload.objectPath);
        } catch (deleteError) {
          req.log.error(
            { err: deleteError, objectPath: upload.objectPath },
            "Failed to clean up replayed vessel photo upload",
          );
        }
        res.status(200).json(result.photo);
        return;
      }
      res.status(201).json(result.photo);
    } catch (error) {
      try {
        await deleteVesselPhoto(upload.objectPath);
      } catch (deleteError) {
        req.log.error(
          { err: deleteError, objectPath: upload.objectPath },
          "Failed to clean up vessel photo upload",
        );
      }
      if (exceededLimit || error instanceof PhotoTooLargeError) {
        res.status(413).json({ error: "Image must be 10 MB or smaller" });
      } else if (error instanceof InvalidPhotoError) {
        res.status(400).json({ error: "Uploaded body is not a valid image" });
      } else if (error instanceof PhotoCapacityError) {
        res.status(400).json({ error: error.message });
      } else {
        req.log.error({ err: error }, "Error uploading vessel photo");
        if (!res.headersSent) res.status(500).json({ error: "Failed to upload photo" });
      }
    }
  },
);

router.post(
  "/vessels/:id/photos",
  requireVesselAuth,
  requireVesselRole(["owner", "admin"]),
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [vessel] = await db
      .select()
      .from(vesselsTable)
      .where(eq(vesselsTable.id, id));
    if (!vessel) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (auth.role !== "admin" && vessel.ownerId !== auth.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    const { objectPath } = req.body ?? {};
    if (!objectPath) {
      res.status(400).json({ error: "objectPath is required" });
      return;
    }
    const path = String(objectPath);
    if (!/^https?:\/\//i.test(path)) {
      res.status(400).json({ error: "Only legacy http(s) photo URLs can be registered" });
      return;
    }
    const legacyPhoto = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(${PHOTO_VESSEL_LOCK_NAMESPACE}, ${id})`);
      const existing = await tx
        .select({ id: vesselPhotosTable.id })
        .from(vesselPhotosTable)
        .where(eq(vesselPhotosTable.vesselId, id));
      if (existing.length >= MAX_VESSEL_PHOTOS) return null;
      const [created] = await tx
        .insert(vesselPhotosTable)
        .values({ vesselId: id, objectPath: path, sortOrder: existing.length })
        .returning();
      return created;
    });
    if (!legacyPhoto) {
      res.status(400).json({ error: "Maximum 5 photos per vessel" });
      return;
    }
    res.status(201).json(legacyPhoto);
  },
);

router.delete(
  "/vessels/:id/photos/:photoId",
  requireVesselAuth,
  requireVesselRole(["owner", "admin"]),
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    const photoId = pId(req.params.photoId);
    if (isNaN(id) || isNaN(photoId)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [vessel] = await db
      .select()
      .from(vesselsTable)
      .where(eq(vesselsTable.id, id));
    if (!vessel) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (auth.role !== "admin" && vessel.ownerId !== auth.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    const [photo] = await db
      .select()
      .from(vesselPhotosTable)
      .where(
        and(
          eq(vesselPhotosTable.id, photoId),
          eq(vesselPhotosTable.vesselId, id),
        ),
      );
    if (!photo) {
      res.status(404).json({ error: "Photo not found" });
      return;
    }
    await db
      .delete(vesselPhotosTable)
      .where(
        and(
          eq(vesselPhotosTable.id, photoId),
          eq(vesselPhotosTable.vesselId, id),
        ),
      );
    try {
      const [remainingReference] = await db
        .select({ id: vesselPhotosTable.id })
        .from(vesselPhotosTable)
        .where(eq(vesselPhotosTable.objectPath, photo.objectPath));
      if (!remainingReference) await deleteVesselPhoto(photo.objectPath);
    } catch (error) {
      req.log.error({ err: error, photoId }, "Failed to delete vessel photo object");
    }
    res.status(204).end();
  },
);

// ── CHARTER PARTIES ───────────────────────────────────────────────────────────

router.post(
  "/vessels/:id/charter",
  requireVesselAuth,
  requireVesselRole(["client", "broker", "admin"]),
  async (req, res): Promise<void> => {
    const vesselId = pId(req.params.id);
    if (isNaN(vesselId)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [vessel] = await db
      .select()
      .from(vesselsTable)
      .where(eq(vesselsTable.id, vesselId));
    if (!vessel) {
      res.status(404).json({ error: "Vessel not found" });
      return;
    }
    if (vessel.status !== "available") {
      res.status(400).json({ error: "Vessel not available for charter" });
      return;
    }
    const auth = req.vesselAuth!;
    if (auth.userId === vessel.ownerId) {
      res.status(400).json({ error: "Owners cannot charter their own vessel" });
      return;
    }
    const {
      rate,
      rateCurrency,
      rateBasis,
      laycanEarliest,
      laycanLatest,
      durationDays,
      cargoPurpose,
      terms,
    } = req.body ?? {};

    const [cp] = await db
      .insert(charterPartiesTable)
      .values({
        vesselId,
        chartererId: auth.userId,
        ownerId: vessel.ownerId,
        rate: rate ? String(rate) : null,
        rateCurrency: rateCurrency ?? "USD",
        rateBasis: rateBasis ?? null,
        laycanEarliest: laycanEarliest ? new Date(laycanEarliest) : null,
        laycanLatest: laycanLatest ? new Date(laycanLatest) : null,
        durationDays: durationDays ? parseInt(durationDays) : null,
        cargoPurpose: cargoPurpose ?? null,
        terms: terms ?? null,
        status: "enquiry",
      })
      .returning();

    await createNotification(
      vessel.ownerId,
      "enquiry_received",
      "New Charter Enquiry",
      `You have received a charter enquiry for ${vessel.name}`,
      cp.id,
    );

    broadcastCharterUpdate(cp.id, cp.ownerId, cp.chartererId);
    res.status(201).json(cp);
  },
);

router.get(
  "/charter-parties",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    await expireHires();
    const auth = req.vesselAuth!;

    const rows = await db
      .select({
        id: charterPartiesTable.id,
        vesselId: charterPartiesTable.vesselId,
        chartererId: charterPartiesTable.chartererId,
        ownerId: charterPartiesTable.ownerId,
        rate: charterPartiesTable.rate,
        rateCurrency: charterPartiesTable.rateCurrency,
        rateBasis: charterPartiesTable.rateBasis,
        laycanEarliest: charterPartiesTable.laycanEarliest,
        laycanLatest: charterPartiesTable.laycanLatest,
        durationDays: charterPartiesTable.durationDays,
        cargoPurpose: charterPartiesTable.cargoPurpose,
        terms: charterPartiesTable.terms,
        status: charterPartiesTable.status,
        ownerConfirmedAt: charterPartiesTable.ownerConfirmedAt,
        chartererConfirmedAt: charterPartiesTable.chartererConfirmedAt,
        hireStart: charterPartiesTable.hireStart,
        hireEnd: charterPartiesTable.hireEnd,
        createdAt: charterPartiesTable.createdAt,
        updatedAt: charterPartiesTable.updatedAt,
        vesselName: vesselsTable.name,
      })
      .from(charterPartiesTable)
      .leftJoin(
        vesselsTable,
        eq(charterPartiesTable.vesselId, vesselsTable.id),
      )
      .orderBy(desc(charterPartiesTable.updatedAt));

    const filtered =
      auth.role === "admin"
        ? rows
        : rows.filter(
            (cp) =>
              cp.chartererId === auth.userId || cp.ownerId === auth.userId,
          );

    const enriched = await Promise.all(
      filtered.map((cp) => enrichCP(cp as Record<string, unknown>)),
    );
    res.json(enriched);
  },
);

router.get(
  "/charter-parties/:id",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [cp] = await db
      .select()
      .from(charterPartiesTable)
      .where(eq(charterPartiesTable.id, id));
    if (!cp) {
      res.status(404).json({ error: "Charter party not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (
      auth.userId !== cp.chartererId &&
      auth.userId !== cp.ownerId &&
      auth.role !== "admin"
    ) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    const [vessel] = await db
      .select({ name: vesselsTable.name })
      .from(vesselsTable)
      .where(eq(vesselsTable.id, cp.vesselId));
    res.json(
      await enrichCP({
        ...(cp as unknown as Record<string, unknown>),
        vesselName: vessel?.name,
      }),
    );
  },
);

router.put(
  "/charter-parties/:id",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [cp] = await db
      .select()
      .from(charterPartiesTable)
      .where(eq(charterPartiesTable.id, id));
    if (!cp) {
      res.status(404).json({ error: "Charter party not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (
      auth.userId !== cp.chartererId &&
      auth.userId !== cp.ownerId &&
      auth.role !== "admin"
    ) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    if (!["enquiry", "negotiating"].includes(cp.status)) {
      res
        .status(400)
        .json({ error: "Cannot edit charter party in this state" });
      return;
    }

    const {
      rate,
      rateCurrency,
      rateBasis,
      laycanEarliest,
      laycanLatest,
      durationDays,
      cargoPurpose,
      terms,
    } = req.body ?? {};

    const updates: Record<string, unknown> = {
      status: "negotiating",
      updatedAt: new Date(),
      ownerConfirmedAt: null,
      chartererConfirmedAt: null,
    };
    if (rate !== undefined) updates.rate = rate ? String(rate) : null;
    if (rateCurrency !== undefined) updates.rateCurrency = rateCurrency;
    if (rateBasis !== undefined) updates.rateBasis = rateBasis;
    if (laycanEarliest !== undefined)
      updates.laycanEarliest = laycanEarliest ? new Date(laycanEarliest) : null;
    if (laycanLatest !== undefined)
      updates.laycanLatest = laycanLatest ? new Date(laycanLatest) : null;
    if (durationDays !== undefined)
      updates.durationDays = durationDays ? parseInt(durationDays) : null;
    if (cargoPurpose !== undefined) updates.cargoPurpose = cargoPurpose;
    if (terms !== undefined) updates.terms = terms;

    const [updated] = await db
      .update(charterPartiesTable)
      .set(updates)
      .where(eq(charterPartiesTable.id, id))
      .returning();

    const [vessel] = await db
      .select({ name: vesselsTable.name })
      .from(vesselsTable)
      .where(eq(vesselsTable.id, cp.vesselId));

    const other =
      auth.userId === cp.chartererId ? cp.ownerId : cp.chartererId;
    await createNotification(
      other,
      "terms_updated",
      "Charter Terms Updated",
      `Terms updated for ${vessel?.name ?? "vessel"} charter`,
      id,
    );

    broadcastCharterUpdate(id, cp.ownerId, cp.chartererId);
    res.json(
      await enrichCP({
        ...(updated as unknown as Record<string, unknown>),
        vesselName: vessel?.name,
      }),
    );
  },
);

router.post(
  "/charter-parties/:id/confirm",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [cp] = await db
      .select()
      .from(charterPartiesTable)
      .where(eq(charterPartiesTable.id, id));
    if (!cp) {
      res.status(404).json({ error: "Charter party not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (
      auth.userId !== cp.chartererId &&
      auth.userId !== cp.ownerId &&
      auth.role !== "admin"
    ) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    if (!["enquiry", "negotiating"].includes(cp.status)) {
      res.status(400).json({ error: "Cannot confirm in this state" });
      return;
    }

    const now = new Date();
    const isOwner = auth.role === "admin" || auth.userId === cp.ownerId;
    const updates: Record<string, unknown> = { updatedAt: now };
    if (isOwner) updates.ownerConfirmedAt = now;
    else updates.chartererConfirmedAt = now;

    const newOwner = isOwner ? now : cp.ownerConfirmedAt;
    const newCharterer = isOwner ? cp.chartererConfirmedAt : now;

    if (newOwner && newCharterer) {
      const conflicts = (
        await db
          .select({ id: charterPartiesTable.id })
          .from(charterPartiesTable)
          .where(
            and(
              eq(charterPartiesTable.vesselId, cp.vesselId),
              inArray(charterPartiesTable.status, ["active", "confirmed"]),
            ),
          )
      ).filter((c) => c.id !== id);
      if (conflicts.length > 0) {
        res
          .status(409)
          .json({ error: "Vessel already has an active or confirmed charter" });
        return;
      }
      const [v] = await db
        .select({ status: vesselsTable.status })
        .from(vesselsTable)
        .where(eq(vesselsTable.id, cp.vesselId));
      if (v?.status === "on_hire") {
        res.status(409).json({ error: "Vessel is already on hire" });
        return;
      }
      updates.status = "active";
      updates.hireStart = now;
      if (cp.durationDays) {
        const end = new Date(now);
        end.setDate(end.getDate() + cp.durationDays);
        updates.hireEnd = end;
      }
      await db
        .update(vesselsTable)
        .set({ status: "on_hire", updatedAt: now })
        .where(eq(vesselsTable.id, cp.vesselId));
    } else {
      updates.status = "negotiating";
    }

    const [updated] = await db
      .update(charterPartiesTable)
      .set(updates)
      .where(eq(charterPartiesTable.id, id))
      .returning();

    const [vessel] = await db
      .select({ name: vesselsTable.name })
      .from(vesselsTable)
      .where(eq(vesselsTable.id, cp.vesselId));

    if (updates.status === "active") {
      await createNotification(
        cp.chartererId,
        "charter_active",
        "Charter Confirmed!",
        `Your charter for ${vessel?.name} is now active`,
        id,
      );
      await createNotification(
        cp.ownerId,
        "charter_active",
        "Charter Confirmed!",
        `Charter for ${vessel?.name} is now active`,
        id,
      );
    } else {
      const other = isOwner ? cp.chartererId : cp.ownerId;
      await createNotification(
        other,
        "party_confirmed",
        "Awaiting Your Confirmation",
        `Please confirm the charter for ${vessel?.name}`,
        id,
      );
    }

    broadcastCharterUpdate(id, cp.ownerId, cp.chartererId);
    res.json(updated);
  },
);

router.post(
  "/charter-parties/:id/decline",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [cp] = await db
      .select()
      .from(charterPartiesTable)
      .where(eq(charterPartiesTable.id, id));
    if (!cp) {
      res.status(404).json({ error: "Charter party not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (
      auth.userId !== cp.chartererId &&
      auth.userId !== cp.ownerId &&
      auth.role !== "admin"
    ) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    if (!["enquiry", "negotiating"].includes(cp.status)) {
      res
        .status(400)
        .json({ error: "Can only decline enquiries or negotiations" });
      return;
    }

    const now = new Date();
    const [updated] = await db
      .update(charterPartiesTable)
      .set({ status: "declined", updatedAt: now })
      .where(eq(charterPartiesTable.id, id))
      .returning();

    const [vessel] = await db
      .select({ name: vesselsTable.name })
      .from(vesselsTable)
      .where(eq(vesselsTable.id, cp.vesselId));

    const other =
      auth.userId === cp.chartererId ? cp.ownerId : cp.chartererId;
    await createNotification(
      other,
      "charter_declined",
      "Charter Enquiry Declined",
      `The charter for ${vessel?.name ?? "vessel"} was declined`,
      id,
    );

    broadcastCharterUpdate(id, cp.ownerId, cp.chartererId);
    res.json(updated);
  },
);

router.post(
  "/charter-parties/:id/terminate",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [cp] = await db
      .select()
      .from(charterPartiesTable)
      .where(eq(charterPartiesTable.id, id));
    if (!cp) {
      res.status(404).json({ error: "Charter party not found" });
      return;
    }
    const auth = req.vesselAuth!;
    if (auth.userId !== cp.ownerId && auth.role !== "admin") {
      res
        .status(403)
        .json({ error: "Only vessel owner or admin can terminate" });
      return;
    }
    if (cp.status !== "active") {
      res
        .status(400)
        .json({ error: "Only active charters can be terminated" });
      return;
    }

    const now = new Date();
    await db
      .update(charterPartiesTable)
      .set({ status: "terminated", updatedAt: now })
      .where(eq(charterPartiesTable.id, id));
    await db
      .update(vesselsTable)
      .set({ status: "available", updatedAt: now })
      .where(eq(vesselsTable.id, cp.vesselId));

    const [vessel] = await db
      .select({ name: vesselsTable.name })
      .from(vesselsTable)
      .where(eq(vesselsTable.id, cp.vesselId));

    await createNotification(
      cp.chartererId,
      "charter_terminated",
      "Charter Terminated",
      `The charter for ${vessel?.name} has been terminated`,
      id,
    );
    await createNotification(
      cp.ownerId,
      "charter_terminated",
      "Charter Terminated",
      `Charter for ${vessel?.name} was terminated`,
      id,
    );

    const [updated] = await db
      .select()
      .from(charterPartiesTable)
      .where(eq(charterPartiesTable.id, id));

    broadcastCharterUpdate(id, cp.ownerId, cp.chartererId);
    res.json(updated);
  },
);

// ── NOTIFICATIONS ─────────────────────────────────────────────────────────────

router.get(
  "/vessel-notifications",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    const rows = await db
      .select()
      .from(vesselNotificationsTable)
      .where(eq(vesselNotificationsTable.userId, req.vesselAuth!.userId))
      .orderBy(desc(vesselNotificationsTable.createdAt));
    res.json(rows);
  },
);

router.patch(
  "/vessel-notifications/:id/read",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const [updated] = await db
      .update(vesselNotificationsTable)
      .set({ read: true })
      .where(
        and(
          eq(vesselNotificationsTable.id, id),
          eq(vesselNotificationsTable.userId, req.vesselAuth!.userId),
        ),
      )
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Not found" });
      return;
    }
    res.json(updated);
  },
);

router.post(
  "/vessel-notifications/read-all",
  requireVesselAuth,
  async (req, res): Promise<void> => {
    await db
      .update(vesselNotificationsTable)
      .set({ read: true })
      .where(
        eq(vesselNotificationsTable.userId, req.vesselAuth!.userId),
      );
    res.json({ ok: true });
  },
);

// ── ADMIN ─────────────────────────────────────────────────────────────────────

router.get(
  "/vessel-admin/users",
  requireVesselAuth,
  requireVesselRole(["admin"]),
  async (_req, res): Promise<void> => {
    const users = await db
      .select({
        id: vesselUsersTable.id,
        name: vesselUsersTable.name,
        email: vesselUsersTable.email,
        role: vesselUsersTable.role,
        company: vesselUsersTable.company,
        phone: vesselUsersTable.phone,
        createdAt: vesselUsersTable.createdAt,
      })
      .from(vesselUsersTable)
      .orderBy(asc(vesselUsersTable.createdAt));
    res.json(users);
  },
);

router.patch(
  "/vessel-admin/users/:id/role",
  requireVesselAuth,
  requireVesselRole(["admin"]),
  async (req, res): Promise<void> => {
    const id = pId(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    const { role } = req.body ?? {};
    if (!["client", "broker", "owner", "admin"].includes(role)) {
      res.status(400).json({ error: "Invalid role" });
      return;
    }
    const [updated] = await db
      .update(vesselUsersTable)
      .set({ role })
      .where(eq(vesselUsersTable.id, id))
      .returning({
        id: vesselUsersTable.id,
        name: vesselUsersTable.name,
        email: vesselUsersTable.email,
        role: vesselUsersTable.role,
        company: vesselUsersTable.company,
        phone: vesselUsersTable.phone,
        createdAt: vesselUsersTable.createdAt,
      });
    if (!updated) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.json(updated);
  },
);

export default router;
