import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { eq } from "drizzle-orm";
import { db, vesselUsersTable } from "@workspace/db";

const JWT_SECRET = process.env.JWT_SECRET;

export interface VesselAuthPayload {
  userId: number;
  email: string;
  role: string;
  scope: string;
}

declare global {
  namespace Express {
    interface Request {
      vesselAuth?: VesselAuthPayload;
    }
  }
}

export async function requireVesselAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  if (!JWT_SECRET) { res.status(503).json({ error: "JWT_SECRET not configured" }); return; }
  const header = req.headers["authorization"];
  if (!header?.startsWith("Bearer ")) { res.status(401).json({ error: "Unauthorized" }); return; }
  try {
    const payload = jwt.verify(header.slice(7), JWT_SECRET) as VesselAuthPayload;
    if (payload.scope !== "vessel") { res.status(401).json({ error: "Unauthorized" }); return; }
    const [user] = await db
      .select({ id: vesselUsersTable.id, role: vesselUsersTable.role })
      .from(vesselUsersTable)
      .where(eq(vesselUsersTable.id, payload.userId));
    if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }
    req.vesselAuth = { ...payload, role: user.role };
    next();
  } catch {
    res.status(401).json({ error: "Unauthorized" });
  }
}

export async function optionalVesselAuth(
  req: Request,
  _res: Response,
  next: NextFunction,
): Promise<void> {
  if (!JWT_SECRET) { next(); return; }
  const header = req.headers["authorization"];
  if (!header?.startsWith("Bearer ")) { next(); return; }
  try {
    const payload = jwt.verify(header.slice(7), JWT_SECRET) as VesselAuthPayload;
    if (payload.scope === "vessel") {
      const [user] = await db
        .select({ id: vesselUsersTable.id, role: vesselUsersTable.role })
        .from(vesselUsersTable)
        .where(eq(vesselUsersTable.id, payload.userId));
      if (user) req.vesselAuth = { ...payload, role: user.role };
    }
  } catch { /* ignore invalid tokens */ }
  next();
}

export function requireVesselRole(roles: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.vesselAuth) { res.status(401).json({ error: "Unauthorized" }); return; }
    if (!roles.includes(req.vesselAuth.role)) { res.status(403).json({ error: "Forbidden" }); return; }
    next();
  };
}
