import { useAuth } from './use-auth';
import { 
  useListVessels, 
  getListVesselsQueryKey,
  useListCharterParties, 
  getListCharterPartiesQueryKey,
  useAdminListUsers, 
  getAdminListUsersQueryKey,
  type ListVesselsParams 
} from '@workspace/api-client-react';

function useAuthHeaders() {
  const { token } = useAuth();
  return {
    Authorization: token ? `Bearer ${token}` : '',
  };
}

export function useAuthedListVessels(params?: ListVesselsParams) {
  const headers = useAuthHeaders();
  const { token } = useAuth();
  
  return useListVessels(params, {
    query: { enabled: !!token, queryKey: getListVesselsQueryKey(params) },
    request: { headers }
  });
}

export function useAuthedListCharterParties() {
  const headers = useAuthHeaders();
  const { token } = useAuth();
  
  return useListCharterParties({
    query: { enabled: !!token, queryKey: getListCharterPartiesQueryKey() },
    request: { headers }
  });
}

export function useAuthedAdminListUsers() {
  const headers = useAuthHeaders();
  const { token } = useAuth();
  
  return useAdminListUsers({
    query: { enabled: !!token, queryKey: getAdminListUsersQueryKey() },
    request: { headers }
  });
}
