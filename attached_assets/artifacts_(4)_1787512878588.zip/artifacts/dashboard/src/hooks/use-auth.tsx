import { createContext, useContext, useState, ReactNode } from 'react';
import type { VesselUser } from '@workspace/api-client-react';

interface AuthContextType {
  user: VesselUser | null;
  token: string | null;
  login: (token: string, user: VesselUser) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<VesselUser | null>(() => {
    const saved = localStorage.getItem('shiphub_user');
    if (!saved) return null;
    try {
      const parsed = JSON.parse(saved) as VesselUser;
      return parsed.role === 'owner' || parsed.role === 'admin' ? parsed : null;
    } catch {
      localStorage.removeItem('shiphub_user');
      return null;
    }
  });
  const [token, setToken] = useState<string | null>(() =>
    user ? localStorage.getItem('shiphub_token') : null,
  );

  const login = (newToken: string, newUser: VesselUser) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem('shiphub_token', newToken);
    localStorage.setItem('shiphub_user', JSON.stringify(newUser));
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('shiphub_token');
    localStorage.removeItem('shiphub_user');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
