import { useState, useMemo } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useAuthedAdminListUsers } from '@/hooks/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, ShieldAlert } from 'lucide-react';
import { format } from 'date-fns';

export default function UsersList() {
  const { user } = useAuth();
  const searchParams = new URLSearchParams(window.location.search);
  const initialRole = searchParams.get('role') || 'all';
  
  const [roleFilter, setRoleFilter] = useState(initialRole);
  const { data: users, isLoading } = useAuthedAdminListUsers();

  const filteredUsers = useMemo(() => {
    if (!users) return [];
    return users.filter(u => {
      return roleFilter === 'all' || u.role === roleFilter;
    });
  }, [users, roleFilter]);

  if (user?.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-2xl font-bold">Access Restricted</h2>
        <p className="text-muted-foreground mt-2">Only administrators can view personnel records.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Personnel Directory</h1>
          <p className="text-muted-foreground">Manage platform access and user roles.</p>
        </div>
      </div>

      <Card className="border-border shadow-sm">
        <CardHeader className="p-4 border-b bg-card pb-4">
          <div className="flex flex-col sm:flex-row justify-end items-center">
            <div className="w-full sm:w-48">
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="owner">Owner</SelectItem>
                  <SelectItem value="client">Client</SelectItem>
                  <SelectItem value="broker">Broker</SelectItem>
                  <SelectItem value="admin">Administrator</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Retrieving personnel records...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="p-12 text-center flex flex-col items-center justify-center text-muted-foreground">
              <Users className="w-12 h-12 mb-4 opacity-20" />
              <p className="text-lg font-medium">No personnel found.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead className="text-right">Joined</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((person) => (
                    <TableRow key={person.id} className="hover:bg-accent/20 cursor-default">
                      <TableCell className="font-medium">{person.name}</TableCell>
                      <TableCell className="text-muted-foreground">{person.email}</TableCell>
                      <TableCell>{person.company || '-'}</TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={
                            person.role === 'admin' ? 'bg-red-50 text-red-700 border-red-200 uppercase text-[10px]' :
                            person.role === 'owner' ? 'bg-blue-50 text-blue-700 border-blue-200 uppercase text-[10px]' :
                            'bg-teal-50 text-teal-700 border-teal-200 uppercase text-[10px]'
                          }
                        >
                          {person.role}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">
                        {format(new Date(person.createdAt), 'MMM d, yyyy')}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
