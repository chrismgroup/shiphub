import { useState, useMemo } from 'react';
import { useAuthedListVessels } from '@/hooks/api';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Ship, Search, SlidersHorizontal, Anchor, Info } from 'lucide-react';
import { format } from 'date-fns';

export default function Fleet() {
  const searchParams = new URLSearchParams(window.location.search);
  const initialStatus = searchParams.get('status') || 'all';
  
  const [statusFilter, setStatusFilter] = useState(initialStatus);
  const [searchQuery, setSearchQuery] = useState('');

  const { data: vessels, isLoading } = useAuthedListVessels();

  const filteredVessels = useMemo(() => {
    if (!vessels) return [];
    return vessels.filter(v => {
      const matchesStatus = statusFilter === 'all' || v.status === statusFilter;
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = 
        !searchQuery || 
        v.name.toLowerCase().includes(searchLower) || 
        (v.imoNumber && v.imoNumber.toLowerCase().includes(searchLower));
      
      return matchesStatus && matchesSearch;
    });
  }, [vessels, statusFilter, searchQuery]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Fleet Status</h1>
          <p className="text-muted-foreground">Monitor and manage your maritime assets.</p>
        </div>
      </div>

      <Card className="border-border shadow-sm">
        <CardHeader className="p-4 border-b bg-card pb-4">
          <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by vessel name or IMO..."
                className="pl-9 bg-background w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="w-full sm:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="on_hire">On Hire</SelectItem>
                  <SelectItem value="laid_up">Laid Up</SelectItem>
                  <SelectItem value="decommissioned">Decommissioned</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Scanning fleet...</div>
          ) : filteredVessels.length === 0 ? (
            <div className="p-12 text-center flex flex-col items-center justify-center text-muted-foreground">
              <Anchor className="w-12 h-12 mb-4 opacity-20" />
              <p className="text-lg font-medium">No vessels found.</p>
              <p className="text-sm">Try adjusting your search or filter parameters.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    <TableHead className="w-[300px]">Vessel Name</TableHead>
                    <TableHead>IMO Number</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>DWT</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Added</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredVessels.map((vessel) => (
                    <TableRow key={vessel.id} className="hover:bg-accent/20 cursor-default">
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center text-primary">
                            <Ship className="w-4 h-4" />
                          </div>
                          {vessel.name}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {vessel.imoNumber || 'N/A'}
                      </TableCell>
                      <TableCell className="capitalize">{vessel.vesselType}</TableCell>
                      <TableCell>{vessel.dwt ? `${vessel.dwt} t` : '-'}</TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={
                            vessel.status === 'available' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                            vessel.status === 'on_hire' ? 'bg-green-50 text-green-700 border-green-200' :
                            'bg-amber-50 text-amber-700 border-amber-200'
                          }
                        >
                          {vessel.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">
                        {format(new Date(vessel.createdAt), 'MMM d, yyyy')}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
