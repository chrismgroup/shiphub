import { useAuth } from '@/hooks/use-auth';
import { useAuthedListVessels, useAuthedListCharterParties, useAuthedAdminListUsers } from '@/hooks/api';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Link } from 'wouter';
import { Ship, FileText, Activity, Anchor, ShieldCheck, Users, AlertCircle, Clock } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

export default function Overview() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight">Console Overview</h1>
        <p className="text-muted-foreground">
          Welcome back to the bridge, {user.name}. Here is your current operations status.
        </p>
      </div>

      {user.role === 'admin' ? <AdminOverview /> : <OwnerOverview />}
    </div>
  );
}

function OwnerOverview() {
  const { data: vessels, isLoading: vesselsLoading } = useAuthedListVessels();
  const { data: charters, isLoading: chartersLoading } = useAuthedListCharterParties();

  if (vesselsLoading || chartersLoading) {
    return <OverviewSkeleton />;
  }

  const totalVessels = vessels?.length || 0;
  const availableVessels = vessels?.filter(v => v.status === 'available').length || 0;
  const onHireVessels = vessels?.filter(v => v.status === 'on_hire').length || 0;
  const laidUpVessels = vessels?.filter(v => v.status === 'laid_up').length || 0;

  const activeCharters = charters?.filter(c => c.status === 'active') || [];
  const newEnquiries = charters?.filter(c => c.status === 'enquiry') || [];
  const pendingConfirmations =
    charters?.filter(
      c => c.status === 'negotiating' && !c.ownerConfirmedAt,
    ) || [];

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <OverviewCard
          title="Available"
          value={availableVessels}
          icon={Anchor}
          href="/fleet?status=available"
          description="Ready for charter"
          valueClassName="text-primary"
        />
        <OverviewCard
          title="On hire"
          value={onHireVessels}
          icon={ShieldCheck}
          href="/fleet?status=on_hire"
          description="Currently employed"
          valueClassName="text-green-600 dark:text-green-500"
        />
        <OverviewCard
          title="Laid up"
          value={laidUpVessels}
          icon={AlertCircle}
          href="/fleet?status=laid_up"
          description="Not currently trading"
          valueClassName="text-amber-600 dark:text-amber-500"
        />
        <OverviewCard
          title="Fleet size"
          value={totalVessels}
          icon={Ship}
          href="/fleet"
          description="Total managed vessels"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-1 lg:col-span-4 border-t-4 border-t-primary shadow-sm hover:shadow-md transition-all">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" /> Active Operations
            </CardTitle>
            <CardDescription>Currently executing charter parties</CardDescription>
          </CardHeader>
          <CardContent>
            {activeCharters.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground border border-dashed rounded-lg bg-muted/20">
                No active operations at this time.
              </div>
            ) : (
              <div className="space-y-4">
                {activeCharters.slice(0, 5).map(charter => (
                  <Link key={charter.id} href={`/charters?status=active`} className="block">
                    <div className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
                      <div className="space-y-1">
                        <p className="text-sm font-semibold">{charter.vesselName || `Vessel #${charter.vesselId}`}</p>
                        <p className="text-xs text-muted-foreground font-mono">
                          {charter.rateCurrency} {charter.rate} / {charter.rateBasis}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-950/30 dark:text-green-400">
                          Active
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">
                          Until {charter.hireEnd ? format(new Date(charter.hireEnd), 'MMM d, yyyy') : 'TBD'}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 lg:col-span-3 shadow-sm hover:shadow-md transition-all">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-600" /> Charter actions
            </CardTitle>
            <CardDescription>New requests and confirmations that need your attention</CardDescription>
          </CardHeader>
          <CardContent>
            {newEnquiries.length === 0 && pendingConfirmations.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground border border-dashed rounded-lg bg-muted/20">
                All clear. No pending requests.
              </div>
            ) : (
              <div className="space-y-4">
                <Link href="/charters?status=enquiry" className="block">
                  <div className="flex items-center justify-between p-4 rounded-lg border bg-card hover:border-amber-300 transition-colors">
                    <div>
                      <p className="font-semibold text-sm">New enquiries</p>
                      <p className="text-xs text-muted-foreground">Recently received charter requests</p>
                    </div>
                    <span className="font-mono text-2xl text-amber-600">{newEnquiries.length}</span>
                  </div>
                </Link>
                <Link href="/charters?status=negotiating" className="block">
                  <div className="flex items-center justify-between p-4 rounded-lg border bg-card hover:border-amber-300 transition-colors">
                    <div>
                      <p className="font-semibold text-sm">Awaiting your confirmation</p>
                      <p className="text-xs text-muted-foreground">Charters ready for an owner response</p>
                    </div>
                    <span className="font-mono text-2xl text-amber-600">{pendingConfirmations.length}</span>
                  </div>
                </Link>
                {newEnquiries.slice(0, 3).map(charter => (
                  <Link key={charter.id} href="/charters?status=enquiry" className="block">
                    <div className="flex flex-col p-4 rounded-lg border bg-card hover:border-amber-300 transition-colors gap-2 relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-1 h-full bg-amber-500" />
                      <div className="flex justify-between items-start">
                        <span className="font-semibold text-sm">{charter.vesselName || `Vessel #${charter.vesselId}`}</span>
                        <Badge variant="secondary" className="bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400">
                          Enquiry
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">Requested by {charter.chartererName || 'Charterer'}</p>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function AdminOverview() {
  const { data: vessels, isLoading: vesselsLoading } = useAuthedListVessels();
  const { data: charters, isLoading: chartersLoading } = useAuthedListCharterParties();
  const { data: users, isLoading: usersLoading } = useAuthedAdminListUsers();

  if (vesselsLoading || chartersLoading || usersLoading) {
    return <OverviewSkeleton />;
  }

  const totalVessels = vessels?.length || 0;
  const activeCharters = charters?.filter(charter => charter.status === 'active').length || 0;
  const totalUsers = users?.length || 0;
  
  const ownerCount = users?.filter(u => u.role === 'owner').length || 0;
  const clientCount = users?.filter(u => u.role === 'client').length || 0;
  const brokerCount = users?.filter(u => u.role === 'broker').length || 0;
  const adminCount = users?.filter(u => u.role === 'admin').length || 0;
  const recentCharters = [...(charters || [])]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 4);

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-3">
        <OverviewCard title="Platform Vessels" value={totalVessels} icon={Ship} href="/fleet" description="Total registered assets" />
        <OverviewCard title="Active charters" value={activeCharters} icon={FileText} href="/charters?status=active" description="Currently in hire" />
        <OverviewCard title="Total Users" value={totalUsers} icon={Users} href="/users" description="Active accounts" />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Personnel Distribution</CardTitle>
            <CardDescription>Network users by role</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Link href="/users?role=owner" className="flex items-center justify-between p-3 rounded border hover:bg-accent/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="font-medium">Owners</span>
                </div>
                <span className="font-mono">{ownerCount}</span>
              </Link>
              <Link href="/users?role=client" className="flex items-center justify-between p-3 rounded border hover:bg-accent/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-teal-500" />
                  <span className="font-medium">Clients</span>
                </div>
                <span className="font-mono">{clientCount}</span>
              </Link>
              <Link href="/users?role=broker" className="flex items-center justify-between p-3 rounded border hover:bg-accent/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-violet-500" />
                  <span className="font-medium">Brokers</span>
                </div>
                <span className="font-mono">{brokerCount}</span>
              </Link>
              <Link href="/users?role=admin" className="flex items-center justify-between p-3 rounded border hover:bg-accent/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-red-500" />
                  <span className="font-medium">Administrators</span>
                </div>
                <span className="font-mono">{adminCount}</span>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Recent Network Activity</CardTitle>
            <CardDescription>Latest charter contracts generated</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentCharters.map(charter => (
                <Link key={charter.id} href="/charters" className="flex items-center justify-between border-b pb-3 last:border-0 last:pb-0 hover:text-primary">
                  <div>
                    <p className="text-sm font-semibold">{charter.vesselName || `Vessel ${charter.vesselId}`}</p>
                    <p className="text-xs text-muted-foreground">{charter.ownerName} &harr; {charter.chartererName}</p>
                  </div>
                  <Badge variant="outline" className="uppercase text-[10px] tracking-wider">
                    {charter.status}
                  </Badge>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function OverviewCard({ 
  title, 
  value, 
  icon: Icon, 
  href, 
  description,
  valueClassName
}: { 
  title: string; 
  value: number; 
  icon: React.ElementType; 
  href: string;
  description: string;
  valueClassName?: string;
}) {
  return (
    <Link href={href} className="block group">
      <Card className="h-full hover:border-primary/50 transition-colors shadow-sm relative overflow-hidden group-hover:shadow-md">
        <div className="absolute -right-4 -top-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <Icon className="w-24 h-24" />
        </div>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 z-10 relative">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <Icon className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
        </CardHeader>
        <CardContent className="z-10 relative">
          <div className={cn("text-3xl font-bold font-mono tracking-tight", valueClassName)}>{value}</div>
          <p className="text-xs text-muted-foreground mt-1">
            {description}
          </p>
        </CardContent>
      </Card>
    </Link>
  );
}

function cn(...classes: (string | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

function OverviewSkeleton() {
  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-4">
        {[1,2,3,4].map(i => (
          <Card key={i}>
            <CardHeader className="pb-2"><Skeleton className="h-4 w-24" /></CardHeader>
            <CardContent><Skeleton className="h-8 w-12" /></CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Card><CardContent className="h-64 pt-6"><Skeleton className="h-full w-full" /></CardContent></Card>
        <Card><CardContent className="h-64 pt-6"><Skeleton className="h-full w-full" /></CardContent></Card>
      </div>
    </div>
  );
}
