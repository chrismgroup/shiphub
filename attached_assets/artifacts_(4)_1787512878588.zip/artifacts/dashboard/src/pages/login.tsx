import { useState } from 'react';
import { useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Anchor, Shield } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useVesselLogin, useVesselRegister, VesselRegisterInputRole } from '@workspace/api-client-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';

const loginSchema = z.object({
  email: z.string().email({ message: 'Invalid email address' }),
  password: z.string().min(1, { message: 'Password is required' }),
});

const registerSchema = z.object({
  name: z.string().min(1, { message: 'Name is required' }),
  email: z.string().email({ message: 'Invalid email address' }),
  password: z.string().min(1, { message: 'Password is required' }),
  company: z.string().optional(),
});

export default function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [, setLocation] = useLocation();
  const { login: setAuth } = useAuth();
  const { toast } = useToast();

  const loginMutation = useVesselLogin();
  const registerMutation = useVesselRegister();

  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: { name: '', email: '', password: '', company: '' },
  });

  const onLoginSubmit = (values: z.infer<typeof loginSchema>) => {
    loginMutation.mutate(
      { data: values },
      {
        onSuccess: (data) => {
          if (data.user.role !== 'owner' && data.user.role !== 'admin') {
            toast({
              variant: 'destructive',
              title: 'Console access restricted',
              description: 'ShipHub Dashboard is available to owner and admin accounts only.',
            });
            return;
          }
          setAuth(data.token, data.user);
          toast({
            title: 'Access granted',
            description: 'Welcome to ShipHub Console.',
          });
          setLocation('/');
        },
        onError: () => {
          toast({
            variant: 'destructive',
            title: 'Access denied',
            description: 'Please check your credentials and try again.',
          });
        },
      }
    );
  };

  const onRegisterSubmit = (values: z.infer<typeof registerSchema>) => {
    registerMutation.mutate(
      {
        data: {
          ...values,
          role: VesselRegisterInputRole.owner,
        },
      },
      {
        onSuccess: (data) => {
          setAuth(data.token, data.user);
          toast({
            title: 'Registration successful',
            description: 'Bridge console accessed.',
          });
          setLocation('/');
        },
        onError: () => {
          toast({
            variant: 'destructive',
            title: 'Registration failed',
            description: 'Please check your information and try again.',
          });
        },
      }
    );
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      {/* Visual left panel */}
      <div className="hidden md:flex flex-col flex-1 bg-sidebar text-sidebar-foreground justify-center items-center p-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500 via-transparent to-transparent pointer-events-none" />
        <div className="z-10 max-w-md space-y-6">
          <Anchor className="w-16 h-16 text-primary" />
          <h1 className="text-4xl font-bold font-sans tracking-tight">ShipHub Console</h1>
          <p className="text-sidebar-foreground/70 text-lg leading-relaxed">
            Centralized maritime operations. Monitor your fleet, manage active charter parties, and coordinate seamlessly from a single secure bridge.
          </p>
          <div className="flex items-center gap-2 text-sm text-sidebar-foreground/50 pt-8 border-t border-sidebar-border">
            <Shield className="w-4 h-4" /> Secure Vessel Network
          </div>
        </div>
      </div>

      {/* Auth panel */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12 border-l border-border bg-card">
        <div className="w-full max-w-[400px]">
          <div className="md:hidden mb-8 flex items-center gap-2">
            <Anchor className="w-8 h-8 text-primary" />
            <h1 className="text-2xl font-bold">ShipHub</h1>
          </div>

          <Card className="border-none shadow-none bg-transparent">
            <CardHeader className="px-0 pt-0 pb-6">
              <CardTitle className="text-2xl font-bold">
                {isLogin ? 'Console Access' : 'Register Vessel Owner'}
              </CardTitle>
              <CardDescription className="text-muted-foreground text-base">
                {isLogin
                  ? 'Enter your credentials to access operations.'
                  : 'Create an owner account to manage your fleet.'}
              </CardDescription>
            </CardHeader>
            <CardContent className="px-0">
              {isLogin ? (
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Operations Email</FormLabel>
                          <FormControl>
                            <Input autoComplete="username" placeholder="crew@company.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Passcode</FormLabel>
                          <FormControl>
                            <Input type="password" autoComplete="current-password" placeholder="••••••••" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      className="w-full font-semibold mt-6"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? 'Authenticating...' : 'Sign In'}
                    </Button>
                  </form>
                </Form>
              ) : (
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Maritime Ltd." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input autoComplete="email" placeholder="name@company.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" autoComplete="new-password" placeholder="••••••••" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      className="w-full font-semibold mt-6"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? 'Registering...' : 'Complete Registration'}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
            <CardFooter className="px-0 pt-4 flex justify-center border-t border-border mt-4">
              <Button
                variant="link"
                className="text-muted-foreground"
                onClick={() => setIsLogin(!isLogin)}
              >
                {isLogin
                  ? "Don't have an account? Register as owner"
                  : 'Already registered? Return to sign in'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
