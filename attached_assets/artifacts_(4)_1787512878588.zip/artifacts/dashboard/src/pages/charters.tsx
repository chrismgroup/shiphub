import { useState, useMemo } from 'react';
import { useAuthedListCharterParties } from '@/hooks/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText } from 'lucide-react';
import { format } from 'date-fns';

export default function Charters() {
  const searchParams = new URLSearchParams(window.location.search);
  const initialStatus = searchParams.get('status') || 'all';
  
  const [statusFilter, setStatusFilter] = useState(initialStatus);

  const { data: charters, isLoading } = useAuthedListCharterParties();

  const filteredCharters = useMemo(() => {
    if (!charters) return [];
    return charters.filter(c => {
      return statusFilter === 'all' || c.status === statusFilter;
    });
  }, [charters, statusFilter]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Charter Operations</h1>
          <p className="text-muted-foreground">Monitor active and pending charter agreements.</p>
        </div>
      </div>

      <Card className="border-border shadow-sm">
        <CardHeader className="p-4 border-b bg-card pb-4">
          <div className="flex flex-col sm:flex-row justify-end items-center">
            <div className="w-full sm:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="enquiry">Enquiry</SelectItem>
                  <SelectItem value="negotiating">Negotiating</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="declined">Declined</SelectItem>
                  <SelectItem value="terminated">Terminated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Retrieving charter records...</div>
          ) : filteredCharters.length === 0 ? (
            <div className="p-12 text-center flex flex-col items-center justify-center text-muted-foreground">
              <FileText className="w-12 h-12 mb-4 opacity-20" />
              <p className="text-lg font-medium">No charters found.</p>
              <p className="text-sm">Change the filter criteria to see more.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    <TableHead>Vessel</TableHead>
                    <TableHead>Parties</TableHead>
                    <TableHead>Rate</TableHead>
                    <TableHead>Laycan</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCharters.map((charter) => (
                    <TableRow key={charter.id} className="hover:bg-accent/20 cursor-default">
                      <TableCell className="font-medium">
                        {charter.vesselName || `Vessel #${charter.vesselId}`}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{charter.ownerName}</div>
                        <div className="text-xs text-muted-foreground">{charter.chartererName}</div>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {charter.rate ? `${charter.rateCurrency} ${charter.rate} / ${charter.rateBasis}` : 'TBD'}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {charter.laycanEarliest ? format(new Date(charter.laycanEarliest), 'MMM d') : '-'}
                        {' to '}
                        {charter.laycanLatest ? format(new Date(charter.laycanLatest), 'MMM d') : '-'}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={
                            charter.status === 'active' ? 'bg-green-50 text-green-700 border-green-200' :
                            charter.status === 'enquiry' || charter.status === 'negotiating' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                            charter.status === 'confirmed' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                            'bg-gray-50 text-gray-700 border-gray-200'
                          }
                        >
                          {charter.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">
                        {format(new Date(charter.createdAt), 'MMM d, yyyy')}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
