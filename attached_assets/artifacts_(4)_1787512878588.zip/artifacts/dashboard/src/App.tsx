import { useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

import { AuthProvider, useAuth } from '@/hooks/use-auth';
import { DashboardLayout } from '@/components/layout/dashboard-layout';

import Login from '@/pages/login';
import Overview from '@/pages/overview';
import Fleet from '@/pages/fleet';
import Charters from '@/pages/charters';
import UsersList from '@/pages/users';

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, adminOnly = false }: { component: any, adminOnly?: boolean }) {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation('/login');
    } else if (adminOnly && user?.role !== 'admin') {
      setLocation('/');
    }
  }, [isAuthenticated, user, adminOnly, setLocation]);

  if (!isAuthenticated || (adminOnly && user?.role !== 'admin')) {
    return null;
  }

  return (
    <DashboardLayout>
      <Component />
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      <Route path="/" component={() => <ProtectedRoute component={Overview} />} />
      <Route path="/fleet" component={() => <ProtectedRoute component={Fleet} />} />
      <Route path="/charters" component={() => <ProtectedRoute component={Charters} />} />
      <Route path="/users" component={() => <ProtectedRoute component={UsersList} adminOnly />} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
            <ErrorBoundary resetKey="shiphub-router">
              <Router />
            </ErrorBoundary>
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
