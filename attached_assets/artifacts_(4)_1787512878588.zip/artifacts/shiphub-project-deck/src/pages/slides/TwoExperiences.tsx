export default function TwoExperiences() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg font-body px-[7vw] py-[6vh]">
      <div className="absolute right-[-7vw] top-[-18vh] h-[55vh] w-[35vw] rounded-full border border-accent/10" />
      <div className="absolute right-[3vw] top-[-6vh] h-[28vh] w-[18vw] rounded-full border border-accent/10" />
      <div className="relative flex h-full flex-col">
        <div className="flex items-center justify-between">
          <div className="text-[1.25vw] font-bold uppercase tracking-[0.26em] text-accent">The product split</div>
          <div className="font-display text-[1.45vw] tracking-[0.12em] text-white/45">02 / 06</div>
        </div>
        <h2 className="mt-[4vh] max-w-[63vw] font-display text-[4.4vw] font-semibold leading-[0.98] tracking-[-0.06em] text-text">One product, two focused experiences</h2>
        <div className="mt-[6vh] grid flex-1 grid-cols-2 gap-[3vw]">
          <div className="relative overflow-hidden rounded-[2vw] border border-white/12 bg-[#1e241f] p-[3vw]">
            <div className="absolute right-[-3vw] top-[-5vh] h-[25vw] w-[25vw] rounded-full bg-accent/8" />
            <div className="relative flex h-full flex-col justify-between">
              <div>
                <div className="mb-[4vh] flex items-center justify-between">
                  <span className="font-display text-[3vw] font-semibold tracking-[-0.06em] text-text">01</span>
                  <span className="rounded-full border border-accent/40 px-[1vw] py-[0.8vh] text-[1.2vw] font-bold uppercase tracking-[0.15em] text-accent">For the demand side</span>
                </div>
                <h3 className="font-display text-[3.1vw] font-semibold tracking-[-0.05em] text-text">ShipHub Charterer</h3>
                <p className="mt-[2vh] max-w-[27vw] text-[1.7vw] leading-[1.25] text-white/70">browse vessels, send enquiries, and manage charters</p>
              </div>
              <div className="relative mx-auto mb-[1vh] h-[21vh] w-[12vw] rounded-[1.5vw] border-[0.45vw] border-[#697267] bg-[#111511] p-[0.6vw] shadow-2xl">
                <div className="h-full rounded-[1vw] bg-[#e9ede4] p-[0.7vw]">
                  <div className="h-[0.55vw] w-[3vw] rounded-full bg-[#a7b09f]" />
                  <div className="mt-[2vh] h-[5vh] rounded-[0.7vw] bg-[#c7dcb6]" />
                  <div className="mt-[1.4vh] h-[1vh] w-[6vw] rounded-full bg-[#788273]" />
                  <div className="mt-[1vh] h-[0.8vh] w-[8vw] rounded-full bg-[#c1c9bc]" />
                  <div className="mt-[2vh] h-[1.8vh] w-[4vw] rounded-full bg-[#263126]" />
                </div>
              </div>
            </div>
          </div>
          <div className="relative overflow-hidden rounded-[2vw] border border-accent/25 bg-accent p-[3vw] text-bg">
            <div className="absolute bottom-[-9vh] right-[-4vw] h-[28vw] w-[28vw] rounded-full border-[1.5vw] border-bg/10" />
            <div className="relative flex h-full flex-col justify-between">
              <div>
                <div className="mb-[4vh] flex items-center justify-between">
                  <span className="font-display text-[3vw] font-semibold tracking-[-0.06em]">02</span>
                  <span className="rounded-full border border-bg/25 px-[1vw] py-[0.8vh] text-[1.2vw] font-bold uppercase tracking-[0.15em]">For the supply side</span>
                </div>
                <h3 className="font-display text-[3.1vw] font-semibold tracking-[-0.05em]">ShipHub Owner</h3>
                <p className="mt-[2vh] max-w-[27vw] text-[1.7vw] leading-[1.25] text-bg/70">manage fleet, requests, negotiations, and listing photos</p>
              </div>
              <div className="relative mx-auto mb-[1vh] h-[21vh] w-[12vw] rounded-[1.5vw] border-[0.45vw] border-bg/60 bg-bg p-[0.6vw] shadow-2xl">
                <div className="h-full rounded-[1vw] bg-[#263126] p-[0.7vw]">
                  <div className="h-[0.55vw] w-[3vw] rounded-full bg-accent/70" />
                  <div className="mt-[2vh] grid grid-cols-2 gap-[0.5vw]"><div className="h-[4.7vh] rounded-[0.5vw] bg-accent/80" /><div className="h-[4.7vh] rounded-[0.5vw] bg-white/15" /></div>
                  <div className="mt-[1.4vh] h-[1vh] w-[6vw] rounded-full bg-white/55" />
                  <div className="mt-[1vh] h-[0.8vh] w-[8vw] rounded-full bg-white/15" />
                  <div className="mt-[2vh] h-[1.8vh] w-[4vw] rounded-full bg-accent" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <p className="mt-[3vh] max-w-[74vw] text-[1.55vw] leading-[1.3] text-white/50">Client and broker access stays separate from owner and admin operations</p>
      </div>
    </div>
  );
}