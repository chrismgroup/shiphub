const base = import.meta.env.BASE_URL;

export default function ShipHubCover() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg font-body">
      <img
        src={`${base}shiphub-marina.jpg`}
        crossOrigin="anonymous"
        alt="A calm marina with vessels at first light"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(15,19,16,0.98)_0%,rgba(15,19,16,0.84)_38%,rgba(15,19,16,0.16)_100%)]" />
      <div className="absolute inset-y-0 left-0 w-[1vw] bg-accent" />
      <div className="relative flex h-full w-full flex-col justify-between px-[7vw] py-[7vh]">
        <div className="flex items-center gap-[1vw] text-[1.35vw] font-bold uppercase tracking-[0.26em] text-accent">
          <span className="h-[0.7vw] w-[0.7vw] rounded-full bg-accent" />
          SHIPHUB / PROJECT OVERVIEW
        </div>
        <div className="max-w-[55vw]">
          <p className="mb-[3vh] text-[1.45vw] font-medium uppercase tracking-[0.2em] text-white/65">Built for the charter journey</p>
          <h1 className="font-display text-[8vw] font-semibold leading-[0.9] tracking-[-0.075em] text-text">ShipHub</h1>
          <p className="mt-[4vh] max-w-[38vw] text-[2.25vw] leading-[1.16] text-white/90">A role-focused vessel marketplace for charterers and owners</p>
        </div>
        <div className="flex items-end justify-between text-[1.45vw] text-white/60">
          <span>Charterer + Owner products</span>
          <span className="font-display tracking-[0.12em] text-accent">01 / 06</span>
        </div>
      </div>
    </div>
  );
}