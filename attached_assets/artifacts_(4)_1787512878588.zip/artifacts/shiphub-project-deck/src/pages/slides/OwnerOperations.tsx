export default function OwnerOperations() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg font-body px-[7vw] py-[6vh]">
      <div className="absolute left-0 top-0 h-[1vw] w-[34vw] bg-accent" />
      <div className="relative flex h-full flex-col">
        <div className="flex items-center justify-between">
          <div className="text-[1.25vw] font-bold uppercase tracking-[0.26em] text-accent">The owner workspace</div>
          <div className="font-display text-[1.45vw] tracking-[0.12em] text-white/45">05 / 06</div>
        </div>
        <h2 className="mt-[4vh] max-w-[64vw] font-display text-[4.4vw] font-semibold leading-[0.98] tracking-[-0.06em] text-text">Owner operations built for the real workflow</h2>
        <div className="mt-[6vh] grid flex-1 grid-cols-[0.9fr_1.1fr] gap-[5vw]">
          <div className="relative overflow-hidden rounded-[2vw] border border-white/12 bg-[#202620] p-[2vw]">
            <div className="flex items-center justify-between border-b border-white/10 pb-[1.5vh]"><span className="font-display text-[1.5vw] font-semibold">Fleet / Overview</span><span className="h-[0.8vw] w-[0.8vw] rounded-full bg-accent" /></div>
            <div className="mt-[2vh] rounded-[1.2vw] bg-[#121612] p-[1.3vw]">
              <div className="flex items-center justify-between"><span className="text-[1.15vw] uppercase tracking-[0.14em] text-white/45">Active listings</span><span className="text-[1.15vw] text-accent">Live</span></div>
              <div className="mt-[1.5vh] h-[8vh] rounded-[0.8vw] bg-[linear-gradient(135deg,#8aa980,#30422f)]" />
              <div className="mt-[1.5vh] flex justify-between"><span className="h-[1vh] w-[8vw] rounded-full bg-white/65" /><span className="h-[1vh] w-[3vw] rounded-full bg-accent" /></div>
            </div>
            <div className="mt-[1.4vh] grid grid-cols-2 gap-[1vw]"><div className="h-[10vh] rounded-[1vw] border border-white/10 bg-[#121612] p-[1vw]"><span className="text-[1.1vw] text-white/45">Requests</span><div className="mt-[2vh] h-[1.3vw] w-[4vw] rounded-full bg-accent" /></div><div className="h-[10vh] rounded-[1vw] border border-white/10 bg-[#121612] p-[1vw]"><span className="text-[1.1vw] text-white/45">Photos</span><div className="mt-[2vh] h-[1.3vw] w-[4vw] rounded-full bg-white/60" /></div></div>
            <div className="mt-[1.4vh] rounded-[1vw] border border-accent/25 bg-accent/10 p-[1vw]"><span className="text-[1.1vw] uppercase tracking-[0.14em] text-accent">Next action</span><div className="mt-[1vh] h-[1vw] w-[12vw] rounded-full bg-white/55" /></div>
          </div>
          <div className="grid grid-cols-2 gap-x-[3vw] gap-y-[3vh] content-center">
            <div className="border-t-2 border-accent pt-[1.7vh]"><p className="text-[1.75vw] leading-[1.18] text-text">Create, edit, publish, and update vessel listings</p></div>
            <div className="border-t-2 border-white/25 pt-[1.7vh]"><p className="text-[1.75vw] leading-[1.18] text-text">Manage contacts, vessel status, charter requests, and negotiations</p></div>
            <div className="border-t-2 border-white/25 pt-[1.7vh]"><p className="text-[1.75vw] leading-[1.18] text-text">Upload, reorder, retry, and delete listing photos</p></div>
            <div className="border-t-2 border-accent pt-[1.7vh]"><p className="text-[1.75vw] leading-[1.18] text-accent">Server-streamed uploads enforce image type and a 10 MB limit before storage</p></div>
          </div>
        </div>
      </div>
    </div>
  );
}