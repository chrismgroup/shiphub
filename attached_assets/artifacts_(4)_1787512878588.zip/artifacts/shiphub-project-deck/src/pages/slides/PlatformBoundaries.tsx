export default function PlatformBoundaries() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg font-body px-[7vw] py-[6vh]">
      <div className="absolute right-[-4vw] top-[10vh] h-[48vw] w-[48vw] rounded-full border border-accent/10" />
      <div className="relative flex h-full flex-col">
        <div className="flex items-center justify-between">
          <div className="text-[1.25vw] font-bold uppercase tracking-[0.26em] text-accent">The platform layer</div>
          <div className="font-display text-[1.45vw] tracking-[0.12em] text-white/45">04 / 06</div>
        </div>
        <h2 className="mt-[4vh] max-w-[66vw] font-display text-[4.4vw] font-semibold leading-[0.98] tracking-[-0.06em] text-text">A shared platform with server-enforced boundaries</h2>
        <div className="mt-[6vh] grid flex-1 grid-cols-[1.05fr_0.95fr] gap-[5vw]">
          <div className="relative flex items-center justify-center rounded-[2vw] border border-white/10 bg-[#1b201c] p-[3vw]">
            <div className="absolute left-[8vw] top-[9vw] h-[0.18vw] w-[10vw] bg-accent/45" />
            <div className="absolute bottom-[9vw] left-[8vw] h-[0.18vw] w-[10vw] bg-accent/45" />
            <div className="absolute right-[8vw] top-[9vw] h-[0.18vw] w-[10vw] bg-accent/45" />
            <div className="absolute bottom-[9vw] right-[8vw] h-[0.18vw] w-[10vw] bg-accent/45" />
            <div className="absolute left-[7vw] top-[6vw] flex h-[7vw] w-[10vw] flex-col justify-center rounded-[1vw] border border-accent/35 bg-bg px-[1vw]"><span className="text-[1.15vw] uppercase tracking-[0.15em] text-accent">Clients</span><span className="mt-[0.7vh] font-display text-[1.45vw] font-semibold">Charterer</span></div>
            <div className="absolute bottom-[6vw] left-[7vw] flex h-[7vw] w-[10vw] flex-col justify-center rounded-[1vw] border border-accent/35 bg-bg px-[1vw]"><span className="text-[1.15vw] uppercase tracking-[0.15em] text-accent">Clients</span><span className="mt-[0.7vh] font-display text-[1.45vw] font-semibold">Broker</span></div>
            <div className="absolute right-[7vw] top-[6vw] flex h-[7vw] w-[10vw] flex-col justify-center rounded-[1vw] border border-white/15 bg-bg px-[1vw]"><span className="text-[1.15vw] uppercase tracking-[0.15em] text-white/55">Operations</span><span className="mt-[0.7vh] font-display text-[1.45vw] font-semibold">Owner</span></div>
            <div className="absolute bottom-[6vw] right-[7vw] flex h-[7vw] w-[10vw] flex-col justify-center rounded-[1vw] border border-white/15 bg-bg px-[1vw]"><span className="text-[1.15vw] uppercase tracking-[0.15em] text-white/55">Operations</span><span className="mt-[0.7vh] font-display text-[1.45vw] font-semibold">Admin</span></div>
            <div className="relative z-10 flex h-[13vw] w-[19vw] flex-col items-center justify-center rounded-[1.5vw] border-[0.35vw] border-accent bg-accent text-center text-bg shadow-[0_1.5vw_4vw_rgba(0,0,0,0.28)]">
              <span className="text-[1.15vw] font-bold uppercase tracking-[0.2em]">Shared core</span>
              <span className="mt-[1vh] font-display text-[2.4vw] font-semibold tracking-[-0.06em]">Express API</span>
              <span className="mt-[1vh] text-[1.25vw]">PostgreSQL + WebSockets</span>
            </div>
          </div>
          <div className="flex flex-col justify-center">
            <div className="border-t border-white/15 py-[2.6vh]">
              <p className="text-[1.75vw] leading-[1.2] text-text">Expo mobile apps connect to a shared Express API</p>
            </div>
            <div className="border-t border-white/15 py-[2.6vh]">
              <p className="text-[1.75vw] leading-[1.2] text-text">PostgreSQL stores users, vessels, charters, notifications, and photos</p>
            </div>
            <div className="border-t border-white/15 py-[2.6vh]">
              <p className="text-[1.75vw] leading-[1.2] text-text">WebSockets keep charter changes visible without waiting for refreshes</p>
            </div>
            <div className="border-y border-white/15 py-[2.6vh]">
              <p className="text-[1.75vw] leading-[1.2] text-accent">The API refreshes the current user role from the database on every authenticated request</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}