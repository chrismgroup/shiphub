export default function NextVoyage() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#1b211c] font-body px-[7vw] py-[6vh]">
      <div className="absolute inset-0 opacity-40" style={{ backgroundImage: 'linear-gradient(rgba(184,211,154,0.12) 1px, transparent 1px), linear-gradient(90deg, rgba(184,211,154,0.12) 1px, transparent 1px)', backgroundSize: '5vw 5vw' }} />
      <div className="absolute bottom-[-28vh] right-[-8vw] h-[80vh] w-[80vh] rounded-full border-[0.08vw] border-accent/30" />
      <div className="absolute bottom-[-16vh] right-[4vw] h-[56vh] w-[56vh] rounded-full border-[0.08vw] border-accent/20" />
      <div className="relative flex h-full flex-col">
        <div className="flex items-center justify-between">
          <div className="text-[1.25vw] font-bold uppercase tracking-[0.26em] text-accent">The outcome</div>
          <div className="font-display text-[1.45vw] tracking-[0.12em] text-white/45">06 / 06</div>
        </div>
        <div className="mt-[11vh] max-w-[62vw]">
          <h2 className="font-display text-[6vw] font-semibold leading-[0.92] tracking-[-0.075em] text-text">ShipHub is ready for the next voyage</h2>
        </div>
        <div className="mt-auto grid grid-cols-3 gap-[1.2vw]">
          <div className="border-t-2 border-accent pt-[2vh]"><div className="font-display text-[1.4vw] font-semibold uppercase tracking-[0.14em] text-accent">Charterers</div><p className="mt-[1.5vh] text-[1.65vw] leading-[1.18] text-text">Two focused mobile products replace a role-mixed experience</p><p className="mt-[1.8vh] text-[1.65vw] leading-[1.18] text-white/60">Charterers get a clear path from browsing to booking</p></div>
          <div className="border-t-2 border-white/25 pt-[2vh]"><div className="font-display text-[1.4vw] font-semibold uppercase tracking-[0.14em] text-white/70">Owners</div><p className="mt-[1.5vh] text-[1.65vw] leading-[1.18] text-text">Owners get operational control over fleet and demand</p></div>
          <div className="border-t-2 border-accent pt-[2vh]"><div className="font-display text-[1.4vw] font-semibold uppercase tracking-[0.14em] text-accent">Platform</div><p className="mt-[1.5vh] text-[1.65vw] leading-[1.18] text-accent">Live updates, role isolation, and resilient media handling support dependable day-to-day use</p></div>
        </div>
        <div className="mt-[5vh] flex items-center justify-between border-t border-white/15 pt-[2vh] text-[1.35vw] text-white/50"><span>ShipHub / product overview</span><span className="font-display tracking-[0.14em] text-accent">CHARTER WITH CLARITY</span></div>
      </div>
    </div>
  );
}