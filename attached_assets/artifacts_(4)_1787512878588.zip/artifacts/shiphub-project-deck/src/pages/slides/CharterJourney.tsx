export default function CharterJourney() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg font-body px-[7vw] py-[6vh]">
      <div className="absolute bottom-[-12vh] left-[-5vw] h-[44vh] w-[44vh] rounded-full border border-accent/10" />
      <div className="relative flex h-full flex-col">
        <div className="flex items-center justify-between">
          <div className="text-[1.25vw] font-bold uppercase tracking-[0.26em] text-accent">The charter journey</div>
          <div className="font-display text-[1.45vw] tracking-[0.12em] text-white/45">03 / 06</div>
        </div>
        <h2 className="mt-[4vh] max-w-[59vw] font-display text-[4.4vw] font-semibold leading-[0.98] tracking-[-0.06em] text-text">From discovery to confirmed charter</h2>
        <div className="relative mt-[8vh] grid flex-1 grid-cols-4 gap-[1.3vw]">
          <div className="absolute left-[7vw] right-[7vw] top-[4.1vw] h-[0.14vw] bg-accent/35" />
          <div className="relative flex flex-col">
            <div className="relative z-10 flex h-[8.2vw] w-[8.2vw] items-center justify-center rounded-full border-[0.35vw] border-accent bg-bg font-display text-[3vw] font-semibold text-accent">01</div>
            <h3 className="mt-[4vh] font-display text-[2.25vw] font-semibold leading-[1.02] tracking-[-0.04em]">Browse available vessels and view listing details</h3>
            <div className="mt-[3vh] h-[0.35vw] w-[4vw] bg-accent" />
          </div>
          <div className="relative flex flex-col">
            <div className="relative z-10 flex h-[8.2vw] w-[8.2vw] items-center justify-center rounded-full border-[0.35vw] border-white/25 bg-bg font-display text-[3vw] font-semibold text-text">02</div>
            <h3 className="mt-[4vh] font-display text-[2.25vw] font-semibold leading-[1.02] tracking-[-0.04em]">Submit charter enquiries with dates, destination, and requirements</h3>
            <div className="mt-[3vh] h-[0.35vw] w-[4vw] bg-white/35" />
          </div>
          <div className="relative flex flex-col">
            <div className="relative z-10 flex h-[8.2vw] w-[8.2vw] items-center justify-center rounded-full border-[0.35vw] border-white/25 bg-bg font-display text-[3vw] font-semibold text-text">03</div>
            <h3 className="mt-[4vh] font-display text-[2.25vw] font-semibold leading-[1.02] tracking-[-0.04em]">Negotiate terms with live status updates</h3>
            <div className="mt-[3vh] h-[0.35vw] w-[4vw] bg-white/35" />
          </div>
          <div className="relative flex flex-col">
            <div className="relative z-10 flex h-[8.2vw] w-[8.2vw] items-center justify-center rounded-full border-[0.35vw] border-accent bg-accent font-display text-[3vw] font-semibold text-bg">04</div>
            <h3 className="mt-[4vh] font-display text-[2.25vw] font-semibold leading-[1.02] tracking-[-0.04em] text-accent">Confirm, decline, or terminate charters with notifications for both parties</h3>
            <div className="mt-[3vh] h-[0.35vw] w-[4vw] bg-accent" />
          </div>
        </div>
        <div className="flex items-center gap-[1vw] text-[1.5vw] text-white/50"><span className="h-[0.65vw] w-[0.65vw] rounded-full bg-accent" /> Every state change is visible to the people who need to act on it.</div>
      </div>
    </div>
  );
}