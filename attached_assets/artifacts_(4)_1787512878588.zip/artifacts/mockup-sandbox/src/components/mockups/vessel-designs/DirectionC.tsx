/* Direction C — Harbor
   Warm, professional, human. Dark green primary + amber accents.
   Rounded cards, soft shadows, feels like a trusted brokerage. */

const vessels = [
  {
    id: 1,
    name: "MV Niger Delta Pride",
    type: "Bulk Carrier",
    dwt: "28,500 DWT",
    flag: "🇳🇬",
    built: "2018",
    status: "available",
    rate: "₦4.2M / day",
    broker: "Okafor Marine",
  },
  {
    id: 2,
    name: "MT Lagos Star",
    type: "Oil Tanker",
    dwt: "45,000 DWT",
    flag: "🇳🇬",
    built: "2020",
    status: "on_hire",
    rate: "₦7.8M / day",
    broker: "Adeyemi Shipping",
  },
  {
    id: 3,
    name: "MV Calabar Voyager",
    type: "General Cargo",
    dwt: "12,000 DWT",
    flag: "🇳🇬",
    built: "2015",
    status: "available",
    rate: "₦2.1M / day",
    broker: "Delta Brokers Ltd",
  },
];

const statusConfig: Record<string, { label: string; color: string; bg: string; border: string }> = {
  available: { label: "● Available",  color: "#166534", bg: "#DCFCE7", border: "#BBF7D0" },
  on_hire:   { label: "● On Hire",    color: "#1E40AF", bg: "#DBEAFE", border: "#BFDBFE" },
  laid_up:   { label: "● Laid Up",    color: "#92400E", bg: "#FEF3C7", border: "#FDE68A" },
};

export function DirectionC() {
  return (
    <div style={{
      fontFamily: "'Inter', sans-serif",
      background: "#F7F4EF",
      minHeight: "100vh",
      color: "#1B3A2E",
    }}>
      {/* Status bar */}
      <div style={{ background: "#1B3A2E", height: 44, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px" }}>
        <span style={{ color: "#D4A853", fontSize: 12, fontWeight: 500 }}>9:41</span>
        <span style={{ color: "#D4A853", fontSize: 11 }}>▊▊▊ ● ⬡</span>
      </div>

      {/* Header */}
      <div style={{ background: "#1B3A2E", padding: "20px 20px 28px", borderBottomLeftRadius: 24, borderBottomRightRadius: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <span style={{ fontSize: 20 }}>⚓</span>
              <span style={{ color: "#D4A853", fontSize: 13, fontWeight: 700, letterSpacing: 0.5 }}>Harbor</span>
            </div>
            <h1 style={{
              fontSize: 24, fontWeight: 800, margin: 0,
              color: "#FFFFFF", letterSpacing: -0.7, lineHeight: 1.1,
            }}>
              Find Your Vessel
            </h1>
            <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 13, margin: "4px 0 0", fontWeight: 400 }}>
              47 vessels across Nigerian waters
            </p>
          </div>
          <div style={{
            width: 42, height: 42, borderRadius: 14,
            background: "rgba(212,168,83,0.15)",
            border: "1.5px solid rgba(212,168,83,0.35)",
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
          }}>🔔</div>
        </div>

        {/* Search */}
        <div style={{
          background: "#FFFFFF",
          borderRadius: 14,
          display: "flex",
          alignItems: "center",
          padding: "13px 16px",
          gap: 10,
          boxShadow: "0 4px 20px rgba(0,0,0,0.2)",
        }}>
          <span style={{ color: "#9CA3AF", fontSize: 16 }}>🔍</span>
          <span style={{ color: "#9CA3AF", fontSize: 14 }}>Search by vessel name or type…</span>
          <div style={{
            marginLeft: "auto",
            background: "#1B3A2E",
            borderRadius: 8,
            width: 34, height: 34,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14,
          }}>⚙</div>
        </div>
      </div>

      {/* Section header */}
      <div style={{ padding: "20px 20px 12px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "#1B3A2E", letterSpacing: -0.4 }}>Available Vessels</h2>
          <p style={{ margin: "2px 0 0", fontSize: 12, color: "#9CA3AF" }}>Updated just now</p>
        </div>
        {/* Filter chips */}
        <div style={{ display: "flex", gap: 6 }}>
          {["All", "Bulk", "Tanker"].map((f, i) => (
            <button key={f} style={{
              background: i === 0 ? "#1B3A2E" : "#FFFFFF",
              border: i === 0 ? "none" : "1.5px solid #E5E0D8",
              borderRadius: 20,
              padding: "5px 12px",
              color: i === 0 ? "#FFFFFF" : "#6B7280",
              fontSize: 11,
              fontWeight: 600,
              cursor: "pointer",
              fontFamily: "inherit",
            }}>{f}</button>
          ))}
        </div>
      </div>

      {/* Vessel cards */}
      <div style={{ padding: "0 16px 100px", display: "flex", flexDirection: "column", gap: 14 }}>
        {vessels.map((v) => {
          const s = statusConfig[v.status];
          return (
            <div key={v.id} style={{
              background: "#FFFFFF",
              borderRadius: 18,
              overflow: "hidden",
              boxShadow: "0 2px 16px rgba(27,58,46,0.08), 0 1px 4px rgba(27,58,46,0.06)",
              border: "1.5px solid #EDE8E0",
            }}>
              {/* Photo */}
              <div style={{
                height: 130,
                background: "linear-gradient(135deg, #1B3A2E 0%, #2D5A45 50%, #3A7A5E 100%)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
              }}>
                {/* Subtle wave pattern */}
                <div style={{ opacity: 0.15, fontSize: 60 }}>🌊</div>
                <div style={{ position: "absolute", fontSize: 36 }}>🚢</div>
                <span style={{
                  position: "absolute", top: 12, left: 12,
                  background: s.bg,
                  color: s.color,
                  border: `1px solid ${s.border}`,
                  fontSize: 11,
                  fontWeight: 600,
                  padding: "4px 10px",
                  borderRadius: 20,
                }}>
                  {s.label}
                </span>
                <div style={{
                  position: "absolute", bottom: 12, right: 12,
                  background: "rgba(255,255,255,0.15)",
                  backdropFilter: "blur(8px)",
                  borderRadius: 10,
                  padding: "5px 12px",
                  border: "1px solid rgba(255,255,255,0.25)",
                }}>
                  <span style={{ color: "#FFFFFF", fontSize: 14, fontWeight: 800 }}>{v.rate}</span>
                </div>
              </div>

              {/* Content */}
              <div style={{ padding: "14px 16px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                      <span style={{ fontSize: 13 }}>{v.flag}</span>
                      <span style={{
                        background: "#F0EDE7",
                        color: "#6B5B3E",
                        fontSize: 10,
                        fontWeight: 600,
                        padding: "2px 8px",
                        borderRadius: 20,
                        letterSpacing: 0.3,
                      }}>{v.type}</span>
                    </div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#1B3A2E", margin: 0, letterSpacing: -0.4, lineHeight: 1.2 }}>
                      {v.name}
                    </h3>
                  </div>
                </div>

                {/* Specs row */}
                <div style={{
                  display: "flex",
                  background: "#F7F4EF",
                  borderRadius: 12,
                  padding: "10px 14px",
                  gap: 20,
                  marginBottom: 14,
                  border: "1px solid #EDE8E0",
                }}>
                  {[["Tonnage", v.dwt], ["Built", v.built], ["Broker", v.broker]].map(([lbl, val], i) => (
                    <div key={lbl} style={i === 2 ? { marginLeft: "auto", textAlign: "right" as const } : {}}>
                      <p style={{ margin: 0, fontSize: 10, color: "#9CA3AF", fontWeight: 600, letterSpacing: 0.3 }}>{lbl}</p>
                      <p style={{ margin: "2px 0 0", fontSize: i === 2 ? 11 : 13, fontWeight: i === 2 ? 500 : 700, color: "#1B3A2E" }}>{val}</p>
                    </div>
                  ))}
                </div>

                <div style={{ display: "flex", gap: 10 }}>
                  <button style={{
                    flex: 1,
                    background: "#1B3A2E",
                    color: "#FFFFFF",
                    border: "none",
                    borderRadius: 12,
                    padding: "12px 0",
                    fontSize: 13,
                    fontWeight: 700,
                    cursor: "pointer",
                    fontFamily: "inherit",
                  }}>
                    View Details
                  </button>
                  <button style={{
                    width: 44, height: 44,
                    background: "#FEF9EC",
                    border: "1.5px solid #F0DFA8",
                    borderRadius: 12,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 18,
                    cursor: "pointer",
                  }}>
                    🔖
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom nav */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        background: "#FFFFFF",
        borderTop: "1.5px solid #EDE8E0",
        display: "flex", justifyContent: "space-around",
        padding: "10px 0 20px",
        boxShadow: "0 -4px 20px rgba(27,58,46,0.06)",
      }}>
        {[["⚓","Browse",true],["📋","Charters",false],["🔔","Alerts",false],["👤","Profile",false]].map(([icon, label, active]) => (
          <div key={String(label)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 12,
              background: active ? "#EEF5F1" : "transparent",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 20,
            }}>{icon}</div>
            <span style={{ fontSize: 10, color: active ? "#1B3A2E" : "#D1C8B8", fontWeight: active ? 700 : 400 }}>{String(label)}</span>
            {active && <div style={{ width: 4, height: 4, borderRadius: "50%", background: "#D4A853", marginTop: -2 }} />}
          </div>
        ))}
      </div>
    </div>
  );
}
