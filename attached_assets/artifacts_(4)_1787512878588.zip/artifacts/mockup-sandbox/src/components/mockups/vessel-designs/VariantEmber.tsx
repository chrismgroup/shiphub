/* Variant: Lagos Gold / Ember
   Warm, formal, prestigious. Amber-gold accents on deep charcoal.
   Evokes high-end commodity trading floors — weight, authority, heat. */

const vessels = [
  { id: 1, name: "MV Niger Delta Pride", type: "Bulk Carrier", dwt: "28,500", grt: "18,200", flag: "🇳🇬", built: "2018", status: "available", rate: "₦4.2M", trend: "+12%", imo: "9812345" },
  { id: 2, name: "MT Lagos Star", type: "Oil Tanker", dwt: "45,000", grt: "28,500", flag: "🇳🇬", built: "2020", status: "on_hire", rate: "₦7.8M", trend: "+5%", imo: "9834567" },
  { id: 3, name: "MV Calabar Voyager", type: "General Cargo", dwt: "12,000", grt: "7,800", flag: "🇳🇬", built: "2015", status: "available", rate: "₦2.1M", trend: "—", imo: "9756789" },
];

const statusConfig: Record<string, { label: string; dot: string; glow: string }> = {
  available: { label: "Available", dot: "#4ADE80", glow: "0 0 8px rgba(74,222,128,0.6)" },
  on_hire:   { label: "On Hire",   dot: "#F59E0B", glow: "0 0 8px rgba(245,158,11,0.6)" },
  laid_up:   { label: "Laid Up",   dot: "#EF4444", glow: "0 0 8px rgba(239,68,68,0.5)" },
};

const GOLD = "#D97706";
const GOLD_LIGHT = "#F59E0B";
const BG = "#080501";
const CARD = "#130D03";
const SURFACE = "#1C1405";
const TEXT = "#F5E6CC";
const MUTED = "#6B5A3E";
const BORDER = "rgba(217,119,6,0.18)";

export function VariantEmber() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif", background: BG, minHeight: "100vh", color: TEXT }}>
      {/* Status bar */}
      <div style={{ background: BG, height: 44, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px" }}>
        <span style={{ color: MUTED, fontSize: 12, fontWeight: 500 }}>9:41</span>
        <span style={{ color: MUTED, fontSize: 11 }}>▊▊▊ ● ⬡</span>
      </div>

      {/* Header */}
      <div style={{ padding: "12px 20px 20px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <div style={{
                width: 28, height: 28, borderRadius: 8,
                background: `linear-gradient(135deg, ${GOLD}, #B45309)`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 14,
              }}>⚓</div>
              <span style={{ fontSize: 13, fontWeight: 600, color: GOLD_LIGHT, letterSpacing: 0.3 }}>ShipHub</span>
            </div>
            <h1 style={{ fontSize: 22, fontWeight: 800, margin: 0, color: "#FFF8ED", lineHeight: 1.1, letterSpacing: -0.8 }}>
              Vessel Market
            </h1>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: `rgba(217,119,6,0.1)`,
              border: `1px solid ${BORDER}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16,
            }}>🔔</div>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: `linear-gradient(135deg, ${GOLD}, #92400E)`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16,
            }}>👤</div>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{
          background: `rgba(217,119,6,0.07)`,
          border: `1px solid ${BORDER}`,
          borderRadius: 12, padding: "12px 16px",
          display: "flex", justifyContent: "space-between", marginBottom: 16,
        }}>
          {[["47", "Active Listings"], ["12", "Available Now"], ["₦6.4M", "Avg. Rate/Day"]].map(([val, lbl]) => (
            <div key={lbl} style={{ textAlign: "center" }}>
              <p style={{ margin: 0, fontSize: 18, fontWeight: 800, color: GOLD_LIGHT }}>{val}</p>
              <p style={{ margin: "2px 0 0", fontSize: 9, color: MUTED, fontWeight: 500, letterSpacing: 0.3 }}>{lbl.toUpperCase()}</p>
            </div>
          ))}
        </div>

        {/* Search */}
        <div style={{
          background: SURFACE,
          border: `1px solid ${BORDER}`,
          borderRadius: 10, display: "flex", alignItems: "center",
          padding: "11px 14px", gap: 10,
        }}>
          <span style={{ color: GOLD, fontSize: 14 }}>🔍</span>
          <span style={{ color: "rgba(245,230,204,0.25)", fontSize: 14 }}>Search vessels…</span>
          <div style={{ marginLeft: "auto", background: `rgba(217,119,6,0.12)`, border: `1px solid rgba(217,119,6,0.25)`, borderRadius: 6, padding: "3px 10px", fontSize: 11, color: GOLD_LIGHT, fontWeight: 600 }}>Filter</div>
        </div>
      </div>

      {/* Filter chips */}
      <div style={{ display: "flex", gap: 8, padding: "0 20px 16px", overflowX: "auto" as const }}>
        {["All", "Available", "Bulk Carrier", "Tanker", "Cargo"].map((chip, i) => (
          <button key={chip} style={{
            background: i === 0 ? `linear-gradient(135deg, ${GOLD}, #92400E)` : "rgba(255,255,255,0.04)",
            border: i === 0 ? "none" : `1px solid rgba(255,255,255,0.08)`,
            borderRadius: 20, padding: "7px 14px",
            color: i === 0 ? "#FFF8ED" : MUTED,
            fontSize: 12, fontWeight: i === 0 ? 600 : 400,
            cursor: "pointer", whiteSpace: "nowrap" as const, fontFamily: "inherit",
          }}>{chip}</button>
        ))}
      </div>

      {/* Vessel cards */}
      <div style={{ padding: "0 16px 100px", display: "flex", flexDirection: "column", gap: 12 }}>
        {vessels.map((v) => {
          const s = statusConfig[v.status];
          return (
            <div key={v.id} style={{
              background: CARD,
              border: `1px solid ${BORDER}`,
              borderRadius: 14, overflow: "hidden",
            }}>
              {/* Image area */}
              <div style={{
                height: 110,
                background: "linear-gradient(135deg, #120900 0%, #1E1000 50%, #2A1800 100%)",
                display: "flex", alignItems: "center", justifyContent: "center",
                position: "relative",
              }}>
                <div style={{ opacity: 0.35, fontSize: 48 }}>🚢</div>
                {/* Warm glow orb */}
                <div style={{
                  position: "absolute", top: "50%", left: "50%",
                  transform: "translate(-50%, -50%)",
                  width: 100, height: 100,
                  background: `radial-gradient(circle, rgba(217,119,6,0.2) 0%, transparent 70%)`,
                  pointerEvents: "none",
                }} />
                {/* Rate badge */}
                <div style={{
                  position: "absolute", top: 10, left: 10,
                  background: `rgba(217,119,6,0.12)`,
                  border: `1px solid rgba(217,119,6,0.3)`,
                  borderRadius: 6, padding: "4px 10px",
                }}>
                  <span style={{ fontSize: 13, fontWeight: 800, color: GOLD_LIGHT }}>{v.rate}</span>
                  <span style={{ fontSize: 9, color: MUTED, marginLeft: 3 }}>/day</span>
                </div>
                {/* Status badge */}
                <div style={{
                  position: "absolute", top: 10, right: 10,
                  display: "flex", alignItems: "center", gap: 5,
                  background: "rgba(0,0,0,0.5)",
                  borderRadius: 20, padding: "4px 10px",
                }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.dot, boxShadow: s.glow, display: "inline-block" }} />
                  <span style={{ fontSize: 10, fontWeight: 600, color: "#F5E6CC" }}>{s.label}</span>
                </div>
              </div>

              {/* Content */}
              <div style={{ padding: "12px 14px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div>
                    <p style={{ margin: 0, fontSize: 9, color: "#4B3E26", fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" as const }}>
                      {v.flag} {v.type} · IMO {v.imo}
                    </p>
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#FFF8ED", margin: "3px 0 0", letterSpacing: -0.3 }}>{v.name}</h3>
                  </div>
                  <span style={{ fontSize: 11, color: GOLD_LIGHT, fontWeight: 600, background: `rgba(245,158,11,0.1)`, padding: "2px 7px", borderRadius: 4 }}>{v.trend}</span>
                </div>

                {/* Specs grid */}
                <div style={{
                  display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8,
                  background: SURFACE, borderRadius: 8, padding: "10px 12px", marginBottom: 12,
                  border: `1px solid rgba(217,119,6,0.08)`,
                }}>
                  {[["DWT", v.dwt + " T"], ["GRT", v.grt + " T"], ["Built", v.built]].map(([lbl, val]) => (
                    <div key={lbl}>
                      <p style={{ margin: 0, fontSize: 9, color: "#4B3E26", fontWeight: 600, letterSpacing: 0.5 }}>{lbl}</p>
                      <p style={{ margin: "2px 0 0", fontSize: 12, fontWeight: 700, color: "#C8A96E" }}>{val}</p>
                    </div>
                  ))}
                </div>

                <button style={{
                  width: "100%",
                  background: `linear-gradient(135deg, ${GOLD_LIGHT} 0%, #B45309 100%)`,
                  color: "#FFF8ED", border: "none", borderRadius: 10,
                  padding: "11px 0", fontSize: 13, fontWeight: 700,
                  cursor: "pointer", fontFamily: "inherit", letterSpacing: 0.2,
                }}>View Details →</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom nav */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        background: "rgba(8,5,1,0.96)",
        backdropFilter: "blur(20px)",
        borderTop: `1px solid ${BORDER}`,
        display: "flex", justifyContent: "space-around",
        padding: "10px 0 20px",
      }}>
        {[["⚓","Browse",true],["📋","Charters",false],["🔔","Alerts",false],["👤","Profile",false]].map(([icon, label, active]) => (
          <div key={String(label)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: active ? `rgba(217,119,6,0.15)` : "transparent",
              border: active ? `1px solid rgba(217,119,6,0.3)` : "none",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18,
            }}>{icon}</div>
            <span style={{ fontSize: 10, color: active ? GOLD_LIGHT : "#3D2E18", fontWeight: active ? 600 : 400 }}>{String(label)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
