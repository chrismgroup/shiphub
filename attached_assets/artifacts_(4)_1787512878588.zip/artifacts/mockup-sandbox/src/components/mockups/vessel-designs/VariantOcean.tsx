/* Variant: Deep Ocean / Bioluminescence
   Dark maritime green. Emerald + cyan accents. Organic, nautical depth.
   Evokes the ocean floor — dense, alive, primordial. Less fintech, more sea. */

const vessels = [
  { id: 1, name: "MV Niger Delta Pride", type: "Bulk Carrier", dwt: "28,500", grt: "18,200", flag: "🇳🇬", built: "2018", status: "available", rate: "₦4.2M", trend: "+12%", imo: "9812345" },
  { id: 2, name: "MT Lagos Star", type: "Oil Tanker", dwt: "45,000", grt: "28,500", flag: "🇳🇬", built: "2020", status: "on_hire", rate: "₦7.8M", trend: "+5%", imo: "9834567" },
  { id: 3, name: "MV Calabar Voyager", type: "General Cargo", dwt: "12,000", grt: "7,800", flag: "🇳🇬", built: "2015", status: "available", rate: "₦2.1M", trend: "—", imo: "9756789" },
];

const statusConfig: Record<string, { label: string; dot: string; glow: string }> = {
  available: { label: "Available", dot: "#34D399", glow: "0 0 8px rgba(52,211,153,0.7)" },
  on_hire:   { label: "On Hire",   dot: "#22D3EE", glow: "0 0 8px rgba(34,211,238,0.6)" },
  laid_up:   { label: "Laid Up",   dot: "#FBBF24", glow: "0 0 6px rgba(251,191,36,0.5)" },
};

const EMERALD = "#10B981";
const CYAN = "#06B6D4";
const BG = "#020D08";
const CARD = "#061410";
const SURFACE = "#0A1E16";
const TEXT = "#D1FAE5";
const MUTED = "#2D5445";
const BORDER = "rgba(16,185,129,0.15)";

export function VariantOcean() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif", background: BG, minHeight: "100vh", color: TEXT }}>
      {/* Subtle ocean texture — very faint radial gradient at top */}
      <div style={{
        position: "fixed", top: 0, left: 0, right: 0, height: 300,
        background: "radial-gradient(ellipse 120% 60% at 50% 0%, rgba(16,185,129,0.06) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      {/* Status bar */}
      <div style={{ background: "transparent", height: 44, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px", position: "relative" }}>
        <span style={{ color: MUTED, fontSize: 12, fontWeight: 500 }}>9:41</span>
        <span style={{ color: MUTED, fontSize: 11 }}>▊▊▊ ● ⬡</span>
      </div>

      {/* Header */}
      <div style={{ padding: "12px 20px 20px", position: "relative" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <div style={{
                width: 28, height: 28, borderRadius: 8,
                background: `linear-gradient(135deg, ${EMERALD}, ${CYAN})`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 14,
              }}>🌊</div>
              <span style={{ fontSize: 13, fontWeight: 600, color: EMERALD, letterSpacing: 0.3 }}>ShipHub</span>
            </div>
            <h1 style={{ fontSize: 22, fontWeight: 800, margin: 0, color: "#ECFDF5", lineHeight: 1.1, letterSpacing: -0.8 }}>
              Vessel Market
            </h1>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: `rgba(16,185,129,0.08)`,
              border: `1px solid ${BORDER}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16,
            }}>🔔</div>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: `linear-gradient(135deg, ${EMERALD}, #0E7490)`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 16,
            }}>👤</div>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{
          background: `rgba(16,185,129,0.06)`,
          border: `1px solid ${BORDER}`,
          borderRadius: 12, padding: "12px 16px",
          display: "flex", justifyContent: "space-between", marginBottom: 16,
        }}>
          {[["47", "Active Listings"], ["12", "Available Now"], ["₦6.4M", "Avg. Rate/Day"]].map(([val, lbl]) => (
            <div key={lbl} style={{ textAlign: "center" }}>
              <p style={{ margin: 0, fontSize: 18, fontWeight: 800, color: EMERALD }}>{val}</p>
              <p style={{ margin: "2px 0 0", fontSize: 9, color: MUTED, fontWeight: 500, letterSpacing: 0.3 }}>{lbl.toUpperCase()}</p>
            </div>
          ))}
        </div>

        {/* Search */}
        <div style={{
          background: SURFACE,
          border: `1px solid ${BORDER}`,
          borderRadius: 10, display: "flex", alignItems: "center",
          padding: "11px 14px", gap: 10,
        }}>
          <span style={{ color: EMERALD, fontSize: 14 }}>🔍</span>
          <span style={{ color: "rgba(209,250,229,0.2)", fontSize: 14 }}>Search vessels…</span>
          <div style={{ marginLeft: "auto", background: `rgba(16,185,129,0.1)`, border: `1px solid rgba(16,185,129,0.25)`, borderRadius: 6, padding: "3px 10px", fontSize: 11, color: EMERALD, fontWeight: 600 }}>Filter</div>
        </div>
      </div>

      {/* Filter chips */}
      <div style={{ display: "flex", gap: 8, padding: "0 20px 16px", overflowX: "auto" as const }}>
        {["All", "Available", "Bulk Carrier", "Tanker", "Cargo"].map((chip, i) => (
          <button key={chip} style={{
            background: i === 0 ? `linear-gradient(135deg, ${EMERALD}, #0E7490)` : "rgba(255,255,255,0.03)",
            border: i === 0 ? "none" : `1px solid rgba(255,255,255,0.07)`,
            borderRadius: 20, padding: "7px 14px",
            color: i === 0 ? "#ECFDF5" : MUTED,
            fontSize: 12, fontWeight: i === 0 ? 600 : 400,
            cursor: "pointer", whiteSpace: "nowrap" as const, fontFamily: "inherit",
          }}>{chip}</button>
        ))}
      </div>

      {/* Vessel cards */}
      <div style={{ padding: "0 16px 100px", display: "flex", flexDirection: "column", gap: 12 }}>
        {vessels.map((v) => {
          const s = statusConfig[v.status];
          return (
            <div key={v.id} style={{
              background: CARD,
              border: `1px solid ${BORDER}`,
              borderRadius: 14, overflow: "hidden",
            }}>
              {/* Image area */}
              <div style={{
                height: 110,
                background: "linear-gradient(135deg, #020E08 0%, #041A10 50%, #041E12 100%)",
                display: "flex", alignItems: "center", justifyContent: "center",
                position: "relative",
              }}>
                <div style={{ opacity: 0.3, fontSize: 48 }}>🚢</div>
                {/* Bioluminescent glow */}
                <div style={{
                  position: "absolute", top: "50%", left: "50%",
                  transform: "translate(-50%, -50%)",
                  width: 120, height: 80,
                  background: `radial-gradient(ellipse, rgba(16,185,129,0.18) 0%, rgba(6,182,212,0.08) 40%, transparent 70%)`,
                  pointerEvents: "none",
                }} />
                {/* Rate badge */}
                <div style={{
                  position: "absolute", top: 10, left: 10,
                  background: `rgba(16,185,129,0.1)`,
                  border: `1px solid rgba(16,185,129,0.25)`,
                  borderRadius: 6, padding: "4px 10px",
                }}>
                  <span style={{ fontSize: 13, fontWeight: 800, color: EMERALD }}>{v.rate}</span>
                  <span style={{ fontSize: 9, color: MUTED, marginLeft: 3 }}>/day</span>
                </div>
                {/* Status badge */}
                <div style={{
                  position: "absolute", top: 10, right: 10,
                  display: "flex", alignItems: "center", gap: 5,
                  background: "rgba(0,0,0,0.4)",
                  borderRadius: 20, padding: "4px 10px",
                }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.dot, boxShadow: s.glow, display: "inline-block" }} />
                  <span style={{ fontSize: 10, fontWeight: 600, color: "#D1FAE5" }}>{s.label}</span>
                </div>
              </div>

              {/* Content */}
              <div style={{ padding: "12px 14px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div>
                    <p style={{ margin: 0, fontSize: 9, color: "#1A4032", fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" as const }}>
                      {v.flag} {v.type} · IMO {v.imo}
                    </p>
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#ECFDF5", margin: "3px 0 0", letterSpacing: -0.3 }}>{v.name}</h3>
                  </div>
                  <span style={{ fontSize: 11, color: "#34D399", fontWeight: 600, background: "rgba(52,211,153,0.08)", padding: "2px 7px", borderRadius: 4 }}>{v.trend}</span>
                </div>

                {/* Specs grid */}
                <div style={{
                  display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8,
                  background: SURFACE, borderRadius: 8, padding: "10px 12px", marginBottom: 12,
                  border: `1px solid rgba(16,185,129,0.06)`,
                }}>
                  {[["DWT", v.dwt + " T"], ["GRT", v.grt + " T"], ["Built", v.built]].map(([lbl, val]) => (
                    <div key={lbl}>
                      <p style={{ margin: 0, fontSize: 9, color: "#1A4032", fontWeight: 600, letterSpacing: 0.5 }}>{lbl}</p>
                      <p style={{ margin: "2px 0 0", fontSize: 12, fontWeight: 700, color: "#6EE7B7" }}>{val}</p>
                    </div>
                  ))}
                </div>

                <button style={{
                  width: "100%",
                  background: `linear-gradient(135deg, ${EMERALD} 0%, #0E7490 100%)`,
                  color: "#ECFDF5", border: "none", borderRadius: 10,
                  padding: "11px 0", fontSize: 13, fontWeight: 700,
                  cursor: "pointer", fontFamily: "inherit", letterSpacing: 0.2,
                }}>View Details →</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom nav */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        background: "rgba(2,13,8,0.96)",
        backdropFilter: "blur(20px)",
        borderTop: `1px solid ${BORDER}`,
        display: "flex", justifyContent: "space-around",
        padding: "10px 0 20px",
      }}>
        {[["⚓","Browse",true],["📋","Charters",false],["🔔","Alerts",false],["👤","Profile",false]].map(([icon, label, active]) => (
          <div key={String(label)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: active ? `rgba(16,185,129,0.12)` : "transparent",
              border: active ? `1px solid rgba(16,185,129,0.25)` : "none",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18,
            }}>{icon}</div>
            <span style={{ fontSize: 10, color: active ? EMERALD : "#153324", fontWeight: active ? 600 : 400 }}>{String(label)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
