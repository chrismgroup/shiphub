/* Variant: Ghost / Minimal Light
   Cool, quiet, restrained. Near-white canvas, hairline borders, no fills.
   Evokes a premium research terminal — deliberate, text-forward, undecorated authority. */

const vessels = [
  { id: 1, name: "MV Niger Delta Pride", type: "Bulk Carrier", dwt: "28,500", grt: "18,200", flag: "🇳🇬", built: "2018", status: "available", rate: "₦4.2M", trend: "+12%", imo: "9812345" },
  { id: 2, name: "MT Lagos Star", type: "Oil Tanker", dwt: "45,000", grt: "28,500", flag: "🇳🇬", built: "2020", status: "on_hire", rate: "₦7.8M", trend: "+5%", imo: "9834567" },
  { id: 3, name: "MV Calabar Voyager", type: "General Cargo", dwt: "12,000", grt: "7,800", flag: "🇳🇬", built: "2015", status: "available", rate: "₦2.1M", trend: "—", imo: "9756789" },
];

const statusConfig: Record<string, { label: string; dot: string }> = {
  available: { label: "Available", dot: "#16A34A" },
  on_hire:   { label: "On Hire",   dot: "#2563EB" },
  laid_up:   { label: "Laid Up",   dot: "#DC2626" },
};

const BLUE = "#2563EB";
const BG = "#F9FAFB";
const TEXT = "#0F172A";
const MUTED_TEXT = "#6B7280";
const LIGHT_TEXT = "#9CA3AF";
const BORDER = "#E5E7EB";
const CARD_BG = "#FFFFFF";

export function VariantGhost() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif", background: BG, minHeight: "100vh", color: TEXT }}>
      {/* Status bar */}
      <div style={{ background: BG, height: 44, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px", borderBottom: `1px solid ${BORDER}` }}>
        <span style={{ color: MUTED_TEXT, fontSize: 12, fontWeight: 500 }}>9:41</span>
        <span style={{ color: LIGHT_TEXT, fontSize: 11 }}>▊▊▊ ● ⬡</span>
      </div>

      {/* Header */}
      <div style={{ padding: "16px 20px 20px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: BLUE, letterSpacing: 1.5, textTransform: "uppercase" as const }}>ShipHub</span>
            </div>
            <h1 style={{ fontSize: 24, fontWeight: 800, margin: 0, color: TEXT, lineHeight: 1.1, letterSpacing: -1 }}>
              Vessel Market
            </h1>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: CARD_BG,
              border: `1px solid ${BORDER}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 15, color: MUTED_TEXT,
            }}>🔔</div>
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: CARD_BG,
              border: `1px solid ${BORDER}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 15,
            }}>👤</div>
          </div>
        </div>

        {/* Stats strip — ghost style */}
        <div style={{
          background: CARD_BG,
          border: `1px solid ${BORDER}`,
          borderRadius: 10,
          padding: "14px 16px",
          display: "flex", justifyContent: "space-between", marginBottom: 16,
        }}>
          {[["47", "Active Listings"], ["12", "Available Now"], ["₦6.4M", "Avg. Rate/Day"]].map(([val, lbl], i) => (
            <div key={lbl} style={{ textAlign: "center", borderRight: i < 2 ? `1px solid ${BORDER}` : "none", flex: 1 }}>
              <p style={{ margin: 0, fontSize: 18, fontWeight: 800, color: i === 0 ? TEXT : BLUE }}>{val}</p>
              <p style={{ margin: "3px 0 0", fontSize: 9, color: LIGHT_TEXT, fontWeight: 500, letterSpacing: 0.6 }}>{lbl.toUpperCase()}</p>
            </div>
          ))}
        </div>

        {/* Search — minimal */}
        <div style={{
          background: CARD_BG,
          border: `1px solid ${BORDER}`,
          borderRadius: 8, display: "flex", alignItems: "center",
          padding: "10px 14px", gap: 10,
        }}>
          <span style={{ color: LIGHT_TEXT, fontSize: 14 }}>🔍</span>
          <span style={{ color: LIGHT_TEXT, fontSize: 14 }}>Search vessels…</span>
          <div style={{ marginLeft: "auto", borderLeft: `1px solid ${BORDER}`, paddingLeft: 12, fontSize: 11, color: BLUE, fontWeight: 600 }}>Filter</div>
        </div>
      </div>

      {/* Filter chips — outline only */}
      <div style={{ display: "flex", gap: 8, padding: "0 20px 16px", overflowX: "auto" as const }}>
        {["All", "Available", "Bulk Carrier", "Tanker", "Cargo"].map((chip, i) => (
          <button key={chip} style={{
            background: i === 0 ? BLUE : "transparent",
            border: i === 0 ? `1px solid ${BLUE}` : `1px solid ${BORDER}`,
            borderRadius: 20, padding: "6px 14px",
            color: i === 0 ? "#FFFFFF" : MUTED_TEXT,
            fontSize: 12, fontWeight: i === 0 ? 600 : 400,
            cursor: "pointer", whiteSpace: "nowrap" as const, fontFamily: "inherit",
          }}>{chip}</button>
        ))}
      </div>

      {/* Vessel cards */}
      <div style={{ padding: "0 16px 100px", display: "flex", flexDirection: "column", gap: 10 }}>
        {vessels.map((v) => {
          const s = statusConfig[v.status];
          return (
            <div key={v.id} style={{
              background: CARD_BG,
              border: `1px solid ${BORDER}`,
              borderRadius: 12, overflow: "hidden",
            }}>
              {/* Image area — very clean */}
              <div style={{
                height: 100,
                background: "#F3F4F6",
                display: "flex", alignItems: "center", justifyContent: "center",
                position: "relative", borderBottom: `1px solid ${BORDER}`,
              }}>
                <div style={{ opacity: 0.18, fontSize: 44 }}>🚢</div>
                {/* Rate — top left */}
                <div style={{ position: "absolute", top: 10, left: 12 }}>
                  <span style={{ fontSize: 14, fontWeight: 800, color: TEXT }}>{v.rate}</span>
                  <span style={{ fontSize: 9, color: MUTED_TEXT, marginLeft: 3 }}>/day</span>
                </div>
                {/* Status — top right, text only */}
                <div style={{
                  position: "absolute", top: 12, right: 12,
                  display: "flex", alignItems: "center", gap: 4,
                }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.dot, display: "inline-block" }} />
                  <span style={{ fontSize: 10, fontWeight: 600, color: MUTED_TEXT }}>{s.label}</span>
                </div>
              </div>

              {/* Content */}
              <div style={{ padding: "12px 14px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div>
                    <p style={{ margin: 0, fontSize: 9, color: LIGHT_TEXT, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" as const }}>
                      {v.flag} {v.type} · IMO {v.imo}
                    </p>
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: TEXT, margin: "3px 0 0", letterSpacing: -0.3 }}>{v.name}</h3>
                  </div>
                  <span style={{ fontSize: 11, color: v.trend.startsWith("+") ? "#16A34A" : MUTED_TEXT, fontWeight: 600 }}>{v.trend}</span>
                </div>

                {/* Specs — table-like hairlines */}
                <div style={{
                  display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
                  borderTop: `1px solid ${BORDER}`, borderLeft: `1px solid ${BORDER}`,
                  borderRadius: 6, overflow: "hidden", marginBottom: 12,
                }}>
                  {[["DWT", v.dwt + " T"], ["GRT", v.grt + " T"], ["Built", v.built]].map(([lbl, val]) => (
                    <div key={lbl} style={{ padding: "8px 10px", borderRight: `1px solid ${BORDER}`, borderBottom: `1px solid ${BORDER}` }}>
                      <p style={{ margin: 0, fontSize: 9, color: LIGHT_TEXT, fontWeight: 600, letterSpacing: 0.5 }}>{lbl}</p>
                      <p style={{ margin: "2px 0 0", fontSize: 12, fontWeight: 700, color: TEXT }}>{val}</p>
                    </div>
                  ))}
                </div>

                <button style={{
                  width: "100%",
                  background: CARD_BG,
                  color: BLUE,
                  border: `1.5px solid ${BLUE}`,
                  borderRadius: 8,
                  padding: "10px 0",
                  fontSize: 13, fontWeight: 700,
                  cursor: "pointer", fontFamily: "inherit", letterSpacing: 0.2,
                }}>View Details →</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom nav */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        background: "rgba(249,250,251,0.97)",
        backdropFilter: "blur(12px)",
        borderTop: `1px solid ${BORDER}`,
        display: "flex", justifyContent: "space-around",
        padding: "10px 0 20px",
      }}>
        {[["⚓","Browse",true],["📋","Charters",false],["🔔","Alerts",false],["👤","Profile",false]].map(([icon, label, active]) => (
          <div key={String(label)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 8,
              background: active ? `rgba(37,99,235,0.08)` : "transparent",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 17,
            }}>{icon}</div>
            <span style={{ fontSize: 10, color: active ? BLUE : LIGHT_TEXT, fontWeight: active ? 600 : 400 }}>{String(label)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
