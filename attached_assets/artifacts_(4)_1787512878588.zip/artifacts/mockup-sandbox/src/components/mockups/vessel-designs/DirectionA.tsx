/* Direction A — Lloyd's Register
   Institutional maritime. Deep navy + gold. Playfair Display headings.
   Formal, trustworthy, like a shipping registry. */

const vessels = [
  {
    id: 1,
    name: "MV NIGER DELTA PRIDE",
    type: "Bulk Carrier",
    dwt: "28,500 DWT",
    flag: "🇳🇬",
    built: "2018",
    status: "available",
    rate: "₦4.2M / day",
    imo: "IMO 9812345",
  },
  {
    id: 2,
    name: "MT LAGOS STAR",
    type: "Oil Tanker",
    dwt: "45,000 DWT",
    flag: "🇳🇬",
    built: "2020",
    status: "on_hire",
    rate: "₦7.8M / day",
    imo: "IMO 9834567",
  },
  {
    id: 3,
    name: "MV CALABAR VOYAGER",
    type: "General Cargo",
    dwt: "12,000 DWT",
    flag: "🇳🇬",
    built: "2015",
    status: "available",
    rate: "₦2.1M / day",
    imo: "IMO 9756789",
  },
];

const statusConfig: Record<string, { label: string; color: string; bg: string }> = {
  available: { label: "Available", color: "#1A5C2E", bg: "#E8F5ED" },
  on_hire:   { label: "On Hire",   color: "#7B4A00", bg: "#FDF3E3" },
  laid_up:   { label: "Laid Up",   color: "#5A1A1A", bg: "#FDEAEA" },
};

export function DirectionA() {
  return (
    <div style={{
      fontFamily: "'Inter', sans-serif",
      background: "#F8F6F1",
      minHeight: "100vh",
      color: "#0A1F3C",
    }}>
      {/* Status bar */}
      <div style={{ background: "#0A1F3C", height: 44, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px" }}>
        <span style={{ color: "#B8960C", fontSize: 12, fontWeight: 600, letterSpacing: 1 }}>9:41</span>
        <span style={{ color: "#B8960C", fontSize: 11, letterSpacing: 0.5 }}>▊▊▊ ● ⬡</span>
      </div>

      {/* Header */}
      <div style={{ background: "#0A1F3C", padding: "20px 20px 24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
          <div>
            <p style={{ color: "#B8960C", fontSize: 11, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", margin: 0, marginBottom: 4 }}>
              Nigerian Vessel Registry
            </p>
            <h1 style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              color: "#FFFFFF",
              fontSize: 26,
              fontWeight: 700,
              margin: 0,
              lineHeight: 1.2,
              letterSpacing: -0.5,
            }}>
              Vessel Marketplace
            </h1>
          </div>
          <div style={{
            width: 40, height: 40, borderRadius: "50%",
            border: "1.5px solid #B8960C",
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "#B8960C", fontSize: 18,
          }}>
            ⚓
          </div>
        </div>

        {/* Search */}
        <div style={{
          background: "rgba(255,255,255,0.09)",
          border: "1px solid rgba(184,150,12,0.3)",
          borderRadius: 6,
          display: "flex",
          alignItems: "center",
          padding: "11px 14px",
          gap: 10,
        }}>
          <span style={{ color: "#B8960C", fontSize: 15 }}>⊕</span>
          <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 14, letterSpacing: 0.2 }}>
            Search by name, type or IMO…
          </span>
        </div>
      </div>

      {/* Gold rule */}
      <div style={{ height: 3, background: "linear-gradient(90deg, #B8960C 0%, #E8C84A 50%, #B8960C 100%)" }} />

      {/* Filter tabs */}
      <div style={{ background: "#0E2645", display: "flex", padding: "0 20px", gap: 0 }}>
        {["All Vessels", "Available", "On Hire", "Laid Up"].map((tab, i) => (
          <button key={tab} style={{
            background: "none",
            border: "none",
            padding: "13px 14px",
            color: i === 0 ? "#B8960C" : "rgba(255,255,255,0.45)",
            fontSize: 12,
            fontWeight: i === 0 ? 600 : 400,
            letterSpacing: 0.5,
            borderBottom: i === 0 ? "2px solid #B8960C" : "2px solid transparent",
            cursor: "pointer",
            fontFamily: "inherit",
          }}>{tab}</button>
        ))}
      </div>

      {/* Count */}
      <div style={{ padding: "14px 20px 8px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <p style={{ margin: 0, fontSize: 12, color: "#8A7A5A", letterSpacing: 0.5, fontWeight: 500 }}>
          SHOWING 3 OF 47 VESSELS
        </p>
        <button style={{ background: "none", border: "1px solid #C8B88A", borderRadius: 4, padding: "4px 10px", fontSize: 11, color: "#5A4A2A", letterSpacing: 0.5, cursor: "pointer", fontFamily: "inherit" }}>
          FILTER ▾
        </button>
      </div>

      {/* Vessel cards */}
      <div style={{ padding: "0 16px 24px", display: "flex", flexDirection: "column", gap: 12 }}>
        {vessels.map((v) => {
          const s = statusConfig[v.status];
          return (
            <div key={v.id} style={{
              background: "#FFFFFF",
              borderRadius: 6,
              overflow: "hidden",
              boxShadow: "0 2px 12px rgba(10,31,60,0.08)",
              borderTop: "3px solid #B8960C",
            }}>
              {/* Photo */}
              <div style={{
                height: 120,
                background: "linear-gradient(135deg, #0A1F3C 0%, #1A3A5C 60%, #2A5A8C 100%)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
              }}>
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 36 }}>🚢</div>
                  <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 10, margin: "4px 0 0", letterSpacing: 1 }}>NO PHOTO ON FILE</p>
                </div>
                <span style={{
                  position: "absolute", top: 10, right: 10,
                  background: s.bg, color: s.color,
                  fontSize: 10, fontWeight: 600, letterSpacing: 0.8,
                  padding: "3px 8px", borderRadius: 2,
                }}>
                  {s.label.toUpperCase()}
                </span>
              </div>

              {/* Content */}
              <div style={{ padding: "14px 16px" }}>
                <p style={{ margin: 0, fontSize: 10, color: "#8A7A5A", letterSpacing: 1.5, fontWeight: 600 }}>
                  {v.imo} · {v.flag} {v.type.toUpperCase()}
                </p>
                <h3 style={{
                  fontFamily: "'Playfair Display', Georgia, serif",
                  fontSize: 16, fontWeight: 700,
                  color: "#0A1F3C", margin: "4px 0 10px",
                  letterSpacing: -0.3,
                }}>
                  {v.name}
                </h3>

                <div style={{ display: "flex", gap: 20, marginBottom: 12 }}>
                  {[["DWT", v.dwt], ["Built", v.built]].map(([lbl, val]) => (
                    <div key={lbl}>
                      <p style={{ margin: 0, fontSize: 10, color: "#8A7A5A", letterSpacing: 0.5, fontWeight: 500 }}>{lbl}</p>
                      <p style={{ margin: "1px 0 0", fontSize: 13, fontWeight: 600, color: "#0A1F3C" }}>{val}</p>
                    </div>
                  ))}
                  <div style={{ marginLeft: "auto", textAlign: "right" }}>
                    <p style={{ margin: 0, fontSize: 10, color: "#8A7A5A", letterSpacing: 0.5, fontWeight: 500 }}>CHARTER RATE</p>
                    <p style={{ margin: "1px 0 0", fontSize: 14, fontWeight: 700, color: "#B8960C" }}>{v.rate}</p>
                  </div>
                </div>

                <button style={{
                  width: "100%",
                  background: "#0A1F3C",
                  color: "#B8960C",
                  border: "1px solid #B8960C",
                  borderRadius: 4,
                  padding: "10px 0",
                  fontSize: 12,
                  fontWeight: 600,
                  letterSpacing: 1.5,
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}>
                  VIEW VESSEL DETAILS
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom nav */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        background: "#0A1F3C",
        borderTop: "1px solid rgba(184,150,12,0.3)",
        display: "flex", justifyContent: "space-around",
        padding: "10px 0 20px",
      }}>
        {[["⚓","Browse"],["📋","Charters"],["🔔","Alerts"],["👤","Profile"]].map(([icon, label], i) => (
          <div key={label} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <span style={{ fontSize: 20 }}>{icon}</span>
            <span style={{ fontSize: 10, color: i === 0 ? "#B8960C" : "rgba(255,255,255,0.4)", fontWeight: i === 0 ? 600 : 400, letterSpacing: 0.5 }}>{label.toUpperCase()}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
